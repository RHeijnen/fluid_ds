import { expect, fixture, html, oneEvent, elementUpdated } from "@open-wc/testing";
import { sendKeys } from "@web/test-runner-commands";
import "./define.js";
import type { FluidButton } from "./fluid-button.js";

describe("<fluid-button>", () => {
  it("renders with default variant and size", async () => {
    const el = await fixture<FluidButton>(html`<fluid-button>Click</fluid-button>`);
    expect(el.variant).to.equal("primary");
    expect(el.size).to.equal("md");
    expect(el).shadowDom.to.equal(`
      <button
        class="button variant-primary size-md"
        part="base"
        type="button"
        aria-disabled="false"
      >
        <slot name="prefix"></slot>
        <slot></slot>
        <slot name="suffix"></slot>
      </button>
    `);
  });

  it("reflects variant and size attributes", async () => {
    const el = await fixture<FluidButton>(
      html`<fluid-button variant="ghost" size="lg">Hi</fluid-button>`
    );
    expect(el.getAttribute("variant")).to.equal("ghost");
    expect(el.getAttribute("size")).to.equal("lg");
  });

  it("fires fluid-click on activation", async () => {
    const el = await fixture<FluidButton>(html`<fluid-button>Click</fluid-button>`);
    setTimeout(() => el.shadowRoot!.querySelector("button")!.click());
    const event = await oneEvent(el, "fluid-click");
    expect(event).to.exist;
    expect(event.bubbles).to.be.true;
    expect(event.composed).to.be.true;
    expect(event.cancelable).to.be.true;
  });

  it("submits the nearest light-DOM form when type=submit", async () => {
    const form = await fixture<HTMLFormElement>(html`
      <form>
        <fluid-button type="submit">Save</fluid-button>
      </form>
    `);
    const el = form.querySelector("fluid-button") as FluidButton;
    let submitted = false;
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      submitted = true;
    });

    el.shadowRoot!.querySelector("button")!.click();

    expect(submitted).to.be.true;
    expect(el.shadowRoot!.querySelector("button")!.type).to.equal("button");
  });

  it("allows fluid-click to cancel a requested form action", async () => {
    const form = await fixture<HTMLFormElement>(html`
      <form>
        <fluid-button type="submit">Save</fluid-button>
      </form>
    `);
    const el = form.querySelector("fluid-button") as FluidButton;
    let submitted = false;
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      submitted = true;
    });
    el.addEventListener("fluid-click", (event) => event.preventDefault());

    el.shadowRoot!.querySelector("button")!.click();

    expect(submitted).to.be.false;
  });

  it("resets the nearest light-DOM form when type=reset", async () => {
    const form = await fixture<HTMLFormElement>(html`
      <form>
        <input name="name" value="original" />
        <fluid-button type="reset">Reset</fluid-button>
      </form>
    `);
    const input = form.querySelector("input")!;
    const el = form.querySelector("fluid-button") as FluidButton;
    input.value = "changed";

    el.shadowRoot!.querySelector("button")!.click();

    expect(input.value).to.equal("original");
  });

  it("preserves loading and disabled activation boundaries across reconnect and form-owner moves", async () => {
    const wrapper = await fixture<HTMLDivElement>(html`
      <div>
        <form id="first"><fluid-button type="submit">Save</fluid-button></form>
        <form id="second"></form>
      </div>
    `);
    const first = wrapper.querySelector<HTMLFormElement>("#first")!;
    const second = wrapper.querySelector<HTMLFormElement>("#second")!;
    const el = first.querySelector<FluidButton>("fluid-button")!;
    const submissions = { first: 0, second: 0 };
    first.addEventListener("submit", (event) => {
      event.preventDefault();
      submissions.first += 1;
    });
    second.addEventListener("submit", (event) => {
      event.preventDefault();
      submissions.second += 1;
    });

    el.disabled = true;
    await el.updateComplete;
    el.shadowRoot!.querySelector<HTMLButtonElement>("button")!.click();
    expect(submissions).to.deep.equal({ first: 0, second: 0 });

    el.remove();
    el.disabled = false;
    el.loading = true;
    second.append(el);
    await el.updateComplete;
    const inner = el.shadowRoot!.querySelector<HTMLButtonElement>("button")!;
    expect(inner.disabled).to.be.false;
    expect(inner.getAttribute("aria-disabled")).to.equal("true");
    expect(inner.getAttribute("aria-busy")).to.equal("true");
    inner.focus();
    expect(el.shadowRoot!.activeElement).to.equal(inner);
    inner.click();
    expect(submissions).to.deep.equal({ first: 0, second: 0 });

    el.loading = false;
    await el.updateComplete;
    inner.click();
    expect(submissions).to.deep.equal({ first: 0, second: 1 });
  });

  it("does not fire fluid-click when disabled", async () => {
    const el = await fixture<FluidButton>(html`<fluid-button disabled>Click</fluid-button>`);
    let fired = false;
    el.addEventListener("fluid-click", () => (fired = true));
    el.shadowRoot!.querySelector("button")!.click();
    expect(fired).to.be.false;
  });

  it("sets aria-disabled when disabled is set", async () => {
    const el = await fixture<FluidButton>(html`<fluid-button>Click</fluid-button>`);
    expect(el.getAttribute("aria-disabled")).to.equal("false");
    el.disabled = true;
    await el.updateComplete;
    expect(el.getAttribute("aria-disabled")).to.equal("true");
  });

  it("passes basic accessibility audit", async () => {
    const el = await fixture<FluidButton>(html`<fluid-button>Label</fluid-button>`);
    await expect(el).to.be.accessible();
  });

  /*
   * SC 2.5.8 Target Size (Minimum) [NEW in WCAG 2.2 AA]. Every size
   * variant, including sm, must hit 24×24 CSS px without depending
   * on label length or icon presence. min-block-size + min-inline-size
   * on the inner button enforce the floor.
   * https://www.w3.org/WAI/WCAG22/Understanding/target-size-minimum.html
   */
  it("size=sm meets the 24×24 target-size minimum (SC 2.5.8)", async () => {
    const el = await fixture<FluidButton>(html`<fluid-button size="sm">x</fluid-button>`);
    const inner = el.shadowRoot!.querySelector("button")!;
    const rect = inner.getBoundingClientRect();
    expect(rect.width).to.be.at.least(24);
    expect(rect.height).to.be.at.least(24);
  });

  it("uses an intentional 32px medium height and preserves the configured target floor", async () => {
    const el = await fixture<FluidButton>(html`<fluid-button>Save</fluid-button>`);
    const inner = el.shadowRoot!.querySelector("button")!;

    expect(inner.getBoundingClientRect().height).to.be.closeTo(32, 0.1);
    expect(el.getBoundingClientRect().height).to.be.closeTo(
      inner.getBoundingClientRect().height,
      0.1
    );

    el.style.setProperty("--fluid-target-min", "44px");
    await el.updateComplete;

    expect(inner.getBoundingClientRect().height).to.be.closeTo(44, 0.1);
    expect(el.getBoundingClientRect().height).to.be.closeTo(
      inner.getBoundingClientRect().height,
      0.1
    );
  });

  /*
   * SC 4.1.2 Name, Role, Value. Icon-only buttons MUST carry an
   * aria-label on the host that's forwarded to the inner <button>.
   * Without forwarding, the slotted decorative icon leaves the
   * button effectively unlabelled.
   */
  it("forwards aria-label to the inner button (SC 4.1.2)", async () => {
    const el = await fixture<FluidButton>(
      html`<fluid-button aria-label="More options"></fluid-button>`
    );
    const inner = el.shadowRoot!.querySelector("button")!;
    expect(inner.getAttribute("aria-label")).to.equal("More options");
  });

  it("does not warn for an icon plus visible label while slots initialize", async () => {
    const originalWarn = console.warn;
    const warnings: unknown[][] = [];
    console.warn = (...args: unknown[]) => warnings.push(args);
    try {
      const el = await fixture<FluidButton>(html`
        <fluid-button>
          <fluid-icon slot="prefix" name="download"></fluid-icon>
          Download
        </fluid-button>
      `);
      await el.updateComplete;
      expect(warnings).to.have.length(0);
    } finally {
      console.warn = originalWarn;
    }
  });

  /*
   * delegatesFocus: true means calling .focus() on the host forwards
   * to the inner native <button>. Without it, host.focus() no-ops and
   * keyboard users land on nothing.
   */
  it("lets --fluid-button-focus-ring-color recolor the focus ring", async () => {
    const el = await fixture<FluidButton>(html`<fluid-button>Focus me</fluid-button>`);
    const inner = el.shadowRoot!.querySelector<HTMLButtonElement>("button")!;

    /* The token is published as a @cssproperty, so setting it has to actually
       reach the outline. It was documented but never referenced: the rule hard
       coded the shared --fluid-focus-ring-color, so overriding the button's own
       token silently did nothing. */
    /* The width comes along because this suite runs without the theme
       stylesheet: with --fluid-focus-ring-width unresolved the whole `outline`
       shorthand is invalid at computed-value time and every longhand falls
       back to its initial, which would mask what the color token does. */
    el.style.setProperty("--fluid-button-focus-ring-width", "2px");
    el.style.setProperty("--fluid-button-focus-ring-color", "rgb(255, 0, 0)");
    await elementUpdated(el);

    // :focus-visible needs a keyboard-originated focus, not a .focus() call.
    await sendKeys({ press: "Tab" });
    await elementUpdated(el);

    expect(el.shadowRoot!.activeElement).to.equal(inner);
    expect(inner.matches(":focus-visible")).to.equal(true);
    const outline = getComputedStyle(inner);
    expect(outline.outlineStyle).to.equal("solid");
    expect(outline.outlineColor).to.equal("rgb(255, 0, 0)");
  });

  it("delegates focus from the host to the inner button", async () => {
    const el = await fixture<FluidButton>(html`<fluid-button>Hi</fluid-button>`);
    const inner = el.shadowRoot!.querySelector("button")!;
    el.focus();
    expect(el.shadowRoot!.activeElement).to.equal(inner);
  });

  /*
   * Slotted-label typography must NOT inherit the host page's line-height.
   * The label lives in the light DOM, so a prose context with a large
   * line-height (e.g. Starlight docs at 1.75) would otherwise balloon the
   * button height. :host pins line-height so the button stays compact
   * regardless of surrounding page CSS. Regression for the docs-vs-
   * Storybook height mismatch.
   */
  it("ignores an inherited prose line-height (stays compact)", async () => {
    const wrap = await fixture<HTMLElement>(
      html`<div style="line-height: 2.5; font-size: 16px;">
        <fluid-button>
          <fluid-icon slot="prefix" name="download"></fluid-icon>
          Download
        </fluid-button>
      </div>`
    );
    const el = wrap.querySelector("fluid-button") as FluidButton;
    await el.updateComplete;
    const inner = el.shadowRoot!.querySelector("button")!;
    // A md button with tight line-height + 8px block padding lands well
    // under 40px. Pre-fix, inheriting line-height:2.5 pushed it past 44.
    expect(inner.getBoundingClientRect().height).to.be.lessThan(40);
  });

  /*
   * Markdown / MDX wraps loose label text in a <p> with prose margins.
   * As a flex item, that <p>'s margin grows the button to its margin-box
   *, which is exactly why the docs button ballooned to ~48px while
   * Storybook (raw text node) stayed ~33px. ::slotted(*) { margin: 0 }
   * must neutralize it. Regression for the docs-vs-Storybook mismatch.
   */
  it("ignores margins on a slotted block label (e.g. MDX <p>)", async () => {
    const el = await fixture<FluidButton>(
      html`<fluid-button><p style="margin: 1em 0;">Save changes</p></fluid-button>`
    );
    await el.updateComplete;
    const inner = el.shadowRoot!.querySelector("button")!;
    expect(inner.getBoundingClientRect().height).to.be.lessThan(40);
  });

  /*
   * Tone resolution. Explicit `tone` always wins; without one, primary
   * resolves to "brand" and secondary / ghost resolve to "neutral" so
   * existing markup keeps its visual identity (this is the contract
   * the visual change docs are based on).
   */
  it("explicit tone reflects to data-tone", async () => {
    const el = await fixture<FluidButton>(html`<fluid-button tone="danger">Delete</fluid-button>`);
    expect(el.dataset.tone).to.equal("danger");
  });

  it("defaults to brand tone on primary, neutral on secondary/ghost", async () => {
    const primary = await fixture<FluidButton>(html`<fluid-button>P</fluid-button>`);
    expect(primary.dataset.tone).to.equal("brand");
    const secondary = await fixture<FluidButton>(
      html`<fluid-button variant="secondary">S</fluid-button>`
    );
    expect(secondary.dataset.tone).to.equal("neutral");
    const ghost = await fixture<FluidButton>(html`<fluid-button variant="ghost">G</fluid-button>`);
    expect(ghost.dataset.tone).to.equal("neutral");
  });

  it("setting tone after construction updates data-tone", async () => {
    const el = await fixture<FluidButton>(html`<fluid-button>Hi</fluid-button>`);
    expect(el.dataset.tone).to.equal("brand");
    el.tone = "success";
    await el.updateComplete;
    expect(el.dataset.tone).to.equal("success");
    el.tone = undefined;
    el.variant = "ghost";
    await el.updateComplete;
    expect(el.dataset.tone).to.equal("neutral");
  });

  /* Loading state, spinner, aria-busy, blocks activation but stays focusable. */
  it("loading: spinner + aria-busy, blocks clicks, stays focusable, name stable", async () => {
    const el = await fixture<FluidButton>(html`<fluid-button loading>Save</fluid-button>`);
    const inner = el.shadowRoot!.querySelector("button")!;
    expect(inner.getAttribute("aria-busy")).to.equal("true");
    expect(inner.getAttribute("aria-disabled")).to.equal("true");
    // aria-disabled, NOT native disabled, must stay focusable.
    expect(inner.hasAttribute("disabled")).to.be.false;
    expect(el.shadowRoot!.querySelector(".spinner")).to.exist;
    let fired = false;
    el.addEventListener("fluid-click", () => (fired = true));
    inner.click();
    expect(fired).to.be.false;
    // label stays in the DOM → accessible name unchanged (SC 2.5.3)
    expect(el.textContent!.trim()).to.equal("Save");
  });

  /*
   * Reduced motion: the infinite spinner rotation must be slowed (not left at
   * the fast 0.6s continuous spin) for vestibular-sensitive users. The reduce
   * media query overrides .spinner animation-duration to 1.5s.
   */
  it("loading: spinner slows under prefers-reduced-motion", async () => {
    const originalMatchMedia = window.matchMedia;
    window.matchMedia = ((query: string) =>
      ({
        matches: query.includes("prefers-reduced-motion"),
        media: query,
        onchange: null,
        addEventListener() {},
        removeEventListener() {},
        addListener() {},
        removeListener() {},
        dispatchEvent: () => false
      }) as unknown as MediaQueryList) as typeof window.matchMedia;
    try {
      const el = await fixture<FluidButton>(html`<fluid-button loading>Save</fluid-button>`);
      const spinner = el.shadowRoot!.querySelector(".spinner")!;
      // The reduce block targets .spinner animation-duration. WTR runs in a
      // real Chromium, so the media query + emulation may not be active here;
      // assert the stylesheet carries the slowed override regardless by reading
      // the matching rule from the component's CSS.
      const sheet = el.shadowRoot!.adoptedStyleSheets[0];
      if (!sheet) throw new Error("Button stylesheet is missing");
      const cssText = Array.from(sheet.cssRules)
        .map((r) => r.cssText)
        .join("\n");
      expect(cssText).to.match(/prefers-reduced-motion/);
      expect(cssText).to.match(/\.spinner\s*\{[^}]*animation-duration:\s*1\.5s/);
      expect(spinner).to.exist;
    } finally {
      window.matchMedia = originalMatchMedia;
    }
  });

  /* Toggle button, aria-pressed reflects + flips, fires fluid-change. */
  it("toggle: reflects aria-pressed and flips on activation", async () => {
    const el = await fixture<FluidButton>(html`<fluid-button toggle>Mute</fluid-button>`);
    const inner = el.shadowRoot!.querySelector("button")!;
    expect(inner.getAttribute("aria-pressed")).to.equal("false");
    let detail: { pressed: boolean } | null = null;
    el.addEventListener("fluid-change", (e) => (detail = (e as CustomEvent).detail));
    inner.click();
    await el.updateComplete;
    expect(el.pressed).to.be.true;
    expect(inner.getAttribute("aria-pressed")).to.equal("true");
    expect(detail).to.deep.equal({ pressed: true });
  });

  it("non-toggle buttons do not expose aria-pressed", async () => {
    const el = await fixture<FluidButton>(html`<fluid-button>Go</fluid-button>`);
    expect(el.shadowRoot!.querySelector("button")!.hasAttribute("aria-pressed")).to.be.false;
  });

  /* Caret, built-in dropdown chevron. */
  it("caret: renders the chevron part; a label-less caret is icon-only", async () => {
    const labelled = await fixture<FluidButton>(html`<fluid-button caret>Menu</fluid-button>`);
    expect(labelled.shadowRoot!.querySelector(".caret")).to.exist;
    expect(labelled.shadowRoot!.querySelector("button")!.classList.contains("icon-only")).to.be
      .false;

    const caretOnly = await fixture<FluidButton>(
      html`<fluid-button caret aria-label="More"></fluid-button>`
    );
    await caretOnly.updateComplete;
    expect(caretOnly.shadowRoot!.querySelector("button")!.classList.contains("icon-only")).to.be
      .true;
  });

  it("does not render a caret by default", async () => {
    const el = await fixture<FluidButton>(html`<fluid-button>Plain</fluid-button>`);
    expect(el.shadowRoot!.querySelector(".caret")).to.not.exist;
  });

  /*
   * A <fluid-dropdown> stamps aria-haspopup / aria-expanded / aria-controls on
   * the host trigger. The button forwards them to the inner native button:
   * the element that actually carries the button role (SC 4.1.2).
   */
  it("forwards host-level aria-haspopup/expanded/controls to the inner button", async () => {
    const el = await fixture<FluidButton>(html`<fluid-button caret>Trigger</fluid-button>`);
    el.setAttribute("aria-haspopup", "menu");
    el.setAttribute("aria-expanded", "true");
    el.setAttribute("aria-controls", "menu-1");
    // MutationObserver → requestUpdate is async; let the re-render settle.
    await el.updateComplete;
    await el.updateComplete;
    const inner = el.shadowRoot!.querySelector("button")!;
    expect(inner.getAttribute("aria-haspopup")).to.equal("menu");
    expect(inner.getAttribute("aria-expanded")).to.equal("true");
    expect(inner.getAttribute("aria-controls")).to.equal("menu-1");
  });

  /*
   * Lifecycle: the aria MutationObserver set up in connectedCallback must be
   * disconnected in disconnectedCallback. After remove(), mutating an observed
   * attribute (aria-expanded) must NOT trigger another requestUpdate / render.
   * Locks in the cleanup contract on the empty FluidElement base.
   */
  it("disconnect: aria observer stops firing after the element is removed", async () => {
    const el = await fixture<FluidButton>(html`<fluid-button caret>Trigger</fluid-button>`);
    await el.updateComplete;

    el.remove();
    // Let any pending microtasks settle so the removal is complete.
    await el.updateComplete;

    let updated = false;
    const orig = el.requestUpdate.bind(el);
    el.requestUpdate = ((...args: unknown[]) => {
      updated = true;
      return (orig as (...a: unknown[]) => unknown)(...args);
    }) as typeof el.requestUpdate;

    // Mutate an observed attribute; a live observer would call requestUpdate.
    el.setAttribute("aria-expanded", "true");
    // Give a disconnected observer a chance to (incorrectly) fire.
    await new Promise((resolve) => setTimeout(resolve, 0));

    expect(updated).to.be.false;
  });

  it("draws no primary outline by default and keeps the soft elevation", async () => {
    const el = await fixture<FluidButton>(html`<fluid-button>Save</fluid-button>`);
    const shadow = getComputedStyle(el.shadowRoot!.querySelector("button")!).boxShadow;
    /* Pixel parity with the pre-token look: a zero-width ring, then the two
       built-in layers. The ring must not invalidate the list when the token
       stylesheet is absent (this suite loads none). */
    expect(shadow).to.contain("0px 0px 0px 0px inset");
    expect(shadow).to.contain("0px 1px 2px 0px");
  });

  it("lets --fluid-button-border-width and --fluid-button-shadow restyle every filled variant", async () => {
    for (const variant of ["primary", "secondary"]) {
      const el = await fixture<FluidButton>(
        html`<fluid-button variant=${variant}>Go</fluid-button>`
      );
      el.style.setProperty("--fluid-button-border-width", "3px");
      el.style.setProperty("--fluid-button-border", "rgb(1, 2, 3)");
      el.style.setProperty("--fluid-button-shadow", "0 4px 0 rgb(4, 5, 6)");
      await elementUpdated(el);
      const shadow = getComputedStyle(el.shadowRoot!.querySelector("button")!).boxShadow;
      expect(shadow, variant).to.contain("rgb(1, 2, 3) 0px 0px 0px 3px inset");
      expect(shadow, variant).to.contain("rgb(4, 5, 6) 0px 4px 0px 0px");
    }
  });

  it("routes tone labels through the optional --fluid-<tone>-fg token", async () => {
    const el = await fixture<FluidButton>(
      html`<fluid-button variant="secondary" tone="danger">Delete</fluid-button>`
    );
    el.style.setProperty("--fluid-danger-base", "rgb(250, 0, 0)");
    await elementUpdated(el);
    const inner = el.shadowRoot!.querySelector("button")!;
    // Unset: falls back to the tone's base fill, the previous behavior.
    expect(getComputedStyle(inner).color).to.equal("rgb(250, 0, 0)");
    el.style.setProperty("--fluid-danger-fg", "rgb(120, 0, 0)");
    await elementUpdated(el);
    expect(getComputedStyle(inner).color).to.equal("rgb(120, 0, 0)");
  });
});
