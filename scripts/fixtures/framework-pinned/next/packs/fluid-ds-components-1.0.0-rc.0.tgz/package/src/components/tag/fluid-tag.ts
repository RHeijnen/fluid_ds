import { html, css, type TemplateResult } from "lit";
import { property } from "lit/decorators.js";
import "../icon/define.js";
import { registerIcon } from "@fluid-ds/icons/registry";
import { FluidElement } from "../../internal/base-element.js";

registerIcon(
  "close",
  `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>`
);

export type FluidTagVariant = "neutral" | "info" | "success" | "warning" | "danger";
export type FluidTagSize = "sm" | "md" | "lg";

/**
 * Compact label for status, categories, or selections. Similar visual role
 * to `<fluid-badge>` but slightly larger, supports interaction (removal),
 * and uses a sharper corner radius, meant for stand-alone chips rather
 * than inline annotation.
 *
 * @summary Inline chip with optional remove button.
 *
 * @slot - Tag text or icon content.
 *
 * @csspart base - The pill container.
 * @csspart remove - The remove button (when `removable`).
 *
 * @cssproperty --fluid-tag-bg - Background color (neutral default).
 * @cssproperty --fluid-tag-fg - Foreground color (neutral default).
 * @cssproperty --fluid-tag-border - Outline border color (neutral default).
 * @cssproperty --fluid-tag-info-bg - Info variant background.
 * @cssproperty --fluid-tag-info-fg - Info variant text.
 * @cssproperty --fluid-tag-info-border - Info variant outline.
 * @cssproperty --fluid-tag-success-bg - Success variant background.
 * @cssproperty --fluid-tag-success-fg - Success variant text.
 * @cssproperty --fluid-tag-success-border - Success variant outline.
 * @cssproperty --fluid-tag-warning-bg - Warning variant background.
 * @cssproperty --fluid-tag-warning-fg - Warning variant text.
 * @cssproperty --fluid-tag-warning-border - Warning variant outline.
 * @cssproperty --fluid-tag-danger-bg - Danger variant background.
 * @cssproperty --fluid-tag-danger-fg - Danger variant text.
 * @cssproperty --fluid-tag-danger-border - Danger variant outline.
 * @cssproperty --fluid-tag-focus-ring - Remove button focus ring color.
 *
 * @uses-token --fluid-surface-muted - Neutral background.
 * @uses-token --fluid-text-primary - Neutral text.
 * @uses-token --fluid-border-default - Outline border.
 * @uses-token --fluid-color-brand-50 - Info variant default background.
 * @uses-token --fluid-color-brand-200 - Info variant default border.
 * @uses-token --fluid-color-brand-800 - Info variant default text.
 * @uses-token --fluid-color-emerald-50 - Success variant default background.
 * @uses-token --fluid-color-emerald-200 - Success variant default border.
 * @uses-token --fluid-color-emerald-800 - Success variant default text.
 * @uses-token --fluid-color-amber-50 - Warning variant default background.
 * @uses-token --fluid-color-amber-300 - Warning variant default border.
 * @uses-token --fluid-color-amber-800 - Warning variant default text.
 * @uses-token --fluid-color-red-50 - Danger variant default background.
 * @uses-token --fluid-color-red-200 - Danger variant default border.
 * @uses-token --fluid-color-red-800 - Danger variant default text.
 * @uses-token --fluid-target-min - Remove button minimum hit-target size.
 * @cssproperty --fluid-tag-radius - Corner radius. Falls back to --fluid-radius-sm.
 * @cssproperty --fluid-tag-font-family - Label font. Falls back to --fluid-font-family-sans.
 * @cssproperty --fluid-tag-border-width - Outline stroke width. Falls back to --fluid-border-width-default.
 * @uses-token --fluid-border-width-default - Outline stroke width.
 *
 * @fires fluid-remove - Dispatched when the user clicks the remove button.
 *   Consumers should remove the tag from their data model on this event.
 */
export class FluidTag extends FluidElement {
  static override styles = css`
    :host {
      display: inline-flex;
      vertical-align: middle;
    }

    :host([hidden]) {
      display: none;
    }

    .base {
      display: inline-flex;
      align-items: center;
      gap: var(--fluid-space-1);
      padding: 0 var(--fluid-space-2);
      border-radius: var(--fluid-tag-radius, var(--fluid-radius-sm));
      font-family: var(--fluid-tag-font-family, var(--fluid-font-family-sans));
      font-weight: var(--fluid-font-weight-medium);
      line-height: 1;
      white-space: nowrap;
      background-color: var(--fluid-tag-bg, var(--fluid-surface-muted));
      color: var(--fluid-tag-fg, var(--fluid-text-primary));
      box-shadow: inset 0 0 0 var(--fluid-tag-border-width, var(--fluid-border-width-default, 1px))
        var(--fluid-tag-border, var(--fluid-border-default));
    }

    .size-sm {
      font-size: 11px;
      min-height: 1.125rem;
    }
    .size-md {
      font-size: var(--fluid-font-size-xs);
      min-height: 1.5rem;
    }
    .size-lg {
      font-size: var(--fluid-font-size-sm);
      min-height: 1.75rem;
    }

    .variant-info {
      background-color: var(--fluid-tag-info-bg, var(--fluid-color-brand-50));
      color: var(--fluid-tag-info-fg, var(--fluid-color-brand-800));
      box-shadow: inset 0 0 0 var(--fluid-tag-border-width, var(--fluid-border-width-default, 1px))
        var(--fluid-tag-info-border, var(--fluid-color-brand-200));
    }
    .variant-success {
      background-color: var(--fluid-tag-success-bg, var(--fluid-color-emerald-50));
      color: var(--fluid-tag-success-fg, var(--fluid-color-emerald-800));
      box-shadow: inset 0 0 0 var(--fluid-tag-border-width, var(--fluid-border-width-default, 1px))
        var(--fluid-tag-success-border, var(--fluid-color-emerald-200));
    }
    .variant-warning {
      background-color: var(--fluid-tag-warning-bg, var(--fluid-color-amber-50));
      color: var(--fluid-tag-warning-fg, var(--fluid-color-amber-800));
      box-shadow: inset 0 0 0 var(--fluid-tag-border-width, var(--fluid-border-width-default, 1px))
        var(--fluid-tag-warning-border, var(--fluid-color-amber-300));
    }
    .variant-danger {
      background-color: var(--fluid-tag-danger-bg, var(--fluid-color-red-50));
      color: var(--fluid-tag-danger-fg, var(--fluid-color-red-800));
      box-shadow: inset 0 0 0 var(--fluid-tag-border-width, var(--fluid-border-width-default, 1px))
        var(--fluid-tag-danger-border, var(--fluid-color-red-200));
    }

    .remove {
      all: unset;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 1em;
      height: 1em;
      /*
       * SC 2.5.8 Target Size. The visible glyph is ~0.75em, far below the
       * 24px AA minimum, so the clickable <button> reads --fluid-target-min
       * as a floor for its hit area without enlarging the close icon itself.
       */
      min-width: var(--fluid-target-min, 0px);
      min-height: var(--fluid-target-min, 0px);
      margin-inline-end: -0.25em;
      cursor: pointer;
      border-radius: var(--fluid-radius-full);
      color: inherit;
      opacity: 0.6;
      transition:
        opacity var(--fluid-duration-fast) var(--fluid-easing-standard),
        background-color var(--fluid-duration-fast) var(--fluid-easing-standard);
    }
    .remove:hover,
    .remove:focus-visible {
      opacity: 1;
      background: rgb(0 0 0 / 0.08);
    }
    .remove:focus-visible {
      outline: 2px solid var(--fluid-tag-focus-ring, var(--fluid-focus-ring-color));
      outline-offset: 1px;
    }
    .remove fluid-icon {
      width: 0.75em;
      height: 0.75em;
    }
  `;

  /** Visual variant. */
  @property({ reflect: true }) variant: FluidTagVariant = "neutral";

  /** Size. */
  @property({ reflect: true }) size: FluidTagSize = "md";

  /** Show a removal × button. */
  @property({ type: Boolean, reflect: true }) removable = false;

  /**
   * Accessible name for the remove button.
   *
   * The button carries no text, so its name is the only thing announcing what
   * activating it does. "Remove" is right when the tag stands for something
   * the user added and can drop, but a consumer may use the same × for an
   * action that is not a removal at all — a scope chip whose × returns to a
   * default, say — and a screen reader would then describe the wrong outcome.
   * Living in the shadow root, it cannot be corrected from the outside, so it
   * is exposed here.
   */
  @property({ attribute: "remove-label" })
  get removeLabel(): string {
    return this.removeLabelOverride ?? this.term("remove");
  }
  set removeLabel(value: string | null) {
    this.removeLabelOverride = value;
  }
  private removeLabelOverride: string | null = null;

  /** Disabled state, removal button can't be activated. */
  @property({ type: Boolean, reflect: true }) disabled = false;

  private handleRemove = (e: Event) => {
    e.stopPropagation();
    if (this.disabled) return;
    this.dispatchEvent(new CustomEvent("fluid-remove", { bubbles: true, composed: true }));
  };

  override render(): TemplateResult {
    return html`
      <span part="base" class="base variant-${this.variant} size-${this.size}">
        <slot></slot>
        ${this.removable
          ? html`
              <button
                part="remove"
                class="remove"
                type="button"
                aria-label=${this.removeLabel}
                ?disabled=${this.disabled}
                @click=${this.handleRemove}
              >
                <fluid-icon name="close"></fluid-icon>
              </button>
            `
          : ""}
      </span>
    `;
  }
}
