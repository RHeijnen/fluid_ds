import { expect, fixture, html, oneEvent, elementUpdated, aTimeout } from "@open-wc/testing";
import "./define.js";
import "../../locales/nl.js";
import "../../locales/de.js";
import "../../locales/fr.js";
import "../../locales/es.js";
import "../../locales/ar.js";
import "../button/define.js";
import type { FluidPopconfirm } from "./fluid-popconfirm.js";

const TOKENS =
  "--fluid-surface-base:#ffffff;--fluid-surface-muted:#f4f4f5;" +
  "--fluid-text-primary:#18181b;--fluid-text-secondary:#3f3f46;" +
  "--fluid-border-default:#e4e4e7;--fluid-accent-base:#4f46e5;--fluid-accent-text:#ffffff;" +
  "--fluid-success-base:#16a34a;--fluid-success-text:#ffffff;" +
  "--fluid-danger-base:#dc2626;--fluid-danger-text:#ffffff;--fluid-warning-base:#d97706;" +
  "--fluid-motion:0;";

async function open(el: FluidPopconfirm): Promise<void> {
  const trigger = el.querySelector("fluid-button")!;
  (trigger as HTMLElement).click();
  await elementUpdated(el);
  await aTimeout(20);
}

describe("<fluid-popconfirm>", () => {
  describe("<fluid-popconfirm> localized defaults", () => {
    const readLabels = (control: FluidPopconfirm) => [
      control.shadowRoot!.querySelector(".message")!.textContent!.trim(),
      control.shadowRoot!.querySelector(".confirm")!.textContent!.trim(),
      control.shadowRoot!.querySelector(".cancel")!.textContent!.trim()
    ];
    for (const [locale, expected] of [
      ["nl", ["Weet je het zeker?", "Bevestigen", "Annuleren"]],
      ["de", ["Sind Sie sicher?", "Bestätigen", "Abbrechen"]],
      ["fr", ["Voulez-vous continuer ?", "Confirmer", "Annuler"]],
      ["es", ["¿Quieres continuar?", "Confirmar", "Cancelar"]],
      ["ar", ["هل تريد المتابعة؟", "تأكيد", "إلغاء"]],
      ["fr-CA", ["Voulez-vous continuer ?", "Confirmer", "Annuler"]]
    ] as const) {
      it(`updates owned labels in ${locale} without treating defaults as application overrides`, async () => {
        const wrapper = await fixture<HTMLDivElement>(html`
          <div lang="en"><fluid-popconfirm></fluid-popconfirm></div>
        `);
        const control = wrapper.querySelector<FluidPopconfirm>("fluid-popconfirm")!;
        await control.updateComplete;
        expect(control.hasAttribute("message")).to.equal(false);
        expect(control.hasAttribute("confirm-text")).to.equal(false);
        expect(control.hasAttribute("cancel-text")).to.equal(false);
        wrapper.lang = locale;
        await new Promise((resolve) => setTimeout(resolve, 0));
        await control.updateComplete;
        expect(readLabels(control)).to.deep.equal(expected);
        expect(control.message).to.equal(expected[0]);
        expect(control.confirmText).to.equal(expected[1]);
        expect(control.cancelText).to.equal(expected[2]);
        expect(control.hasAttribute("message")).to.equal(false);
        expect(control.hasAttribute("confirm-text")).to.equal(false);
        expect(control.hasAttribute("cancel-text")).to.equal(false);
      });
    }

    it("refreshes defaults in a closed shadow context and after reconnect", async () => {
      const host = await fixture<HTMLDivElement>(html`<div></div>`);
      const context = document.createElement("section");
      context.lang = "nl";
      host.attachShadow({ mode: "closed" }).append(context);
      const control = await fixture<FluidPopconfirm>(html`<fluid-popconfirm></fluid-popconfirm>`);
      context.append(control);
      await control.updateComplete;
      expect(readLabels(control)).to.deep.equal(["Weet je het zeker?", "Bevestigen", "Annuleren"]);
      context.lang = "de";
      await new Promise((resolve) => setTimeout(resolve, 0));
      await control.updateComplete;
      expect(readLabels(control)).to.deep.equal(["Sind Sie sicher?", "Bestätigen", "Abbrechen"]);
      control.remove();
      context.lang = "ar";
      context.append(control);
      await control.updateComplete;
      expect(readLabels(control)).to.deep.equal(["هل تريد المتابعة؟", "تأكيد", "إلغاء"]);
    });

    it("preserves explicit English and empty overrides, and restores defaults when overrides are removed", async () => {
      const wrapper = await fixture<HTMLDivElement>(html`
        <div lang="en"><fluid-popconfirm></fluid-popconfirm></div>
      `);
      const control = wrapper.querySelector<FluidPopconfirm>("fluid-popconfirm")!;
      control.message = "Are you sure?";
      control.confirmText = "Confirm";
      control.cancelText = "Cancel";
      wrapper.lang = "nl";
      await new Promise((resolve) => setTimeout(resolve, 0));
      await control.updateComplete;
      expect(readLabels(control)).to.deep.equal(["Are you sure?", "Confirm", "Cancel"]);
      control.setAttribute("message", "Are you sure?");
      control.setAttribute("confirm-text", "Confirm");
      control.setAttribute("cancel-text", "Cancel");
      wrapper.lang = "fr";
      await new Promise((resolve) => setTimeout(resolve, 0));
      await control.updateComplete;
      expect(readLabels(control)).to.deep.equal(["Are you sure?", "Confirm", "Cancel"]);
      control.removeAttribute("message");
      control.removeAttribute("confirm-text");
      control.removeAttribute("cancel-text");
      await control.updateComplete;
      expect(readLabels(control)).to.deep.equal([
        "Voulez-vous continuer ?",
        "Confirmer",
        "Annuler"
      ]);
      control.message = "";
      control.confirmText = "";
      control.cancelText = "";
      wrapper.lang = "ar";
      await new Promise((resolve) => setTimeout(resolve, 0));
      await control.updateComplete;
      expect(readLabels(control)).to.deep.equal(["", "", ""]);
      Reflect.set(control, "message", null);
      Reflect.set(control, "confirmText", null);
      Reflect.set(control, "cancelText", null);
      await control.updateComplete;
      expect(readLabels(control)).to.deep.equal(["هل تريد المتابعة؟", "تأكيد", "إلغاء"]);
    });
  });

  it("is closed by default", async () => {
    const el = await fixture<FluidPopconfirm>(html`
      <fluid-popconfirm><fluid-button slot="trigger">X</fluid-button></fluid-popconfirm>
    `);
    expect(el.open).to.be.false;
  });

  it("uses role=alertdialog with aria-modal and aria-describedby", async () => {
    const el = await fixture<FluidPopconfirm>(html`
      <fluid-popconfirm message="Sure?"
        ><fluid-button slot="trigger">X</fluid-button></fluid-popconfirm
      >
    `);
    const panel = el.shadowRoot!.querySelector(".panel")!;
    expect(panel.getAttribute("role")).to.equal("alertdialog");
    expect(panel.getAttribute("aria-modal")).to.equal("true");
    const describedby = panel.getAttribute("aria-describedby");
    expect(describedby).to.be.a("string");
    const msg = el.shadowRoot!.querySelector(`#${describedby}`);
    expect(msg?.textContent?.trim()).to.equal("Sure?");
  });

  it("opens on trigger activation and sets aria-expanded", async () => {
    const el = await fixture<FluidPopconfirm>(html`
      <fluid-popconfirm><fluid-button slot="trigger">X</fluid-button></fluid-popconfirm>
    `);
    await open(el);
    expect(el.open).to.be.true;
    expect(el.querySelector("fluid-button")!.getAttribute("aria-expanded")).to.equal("true");
  });

  it("fires fluid-confirm and closes when confirm is clicked", async () => {
    const el = await fixture<FluidPopconfirm>(html`
      <fluid-popconfirm><fluid-button slot="trigger">X</fluid-button></fluid-popconfirm>
    `);
    await open(el);
    const confirm = el.shadowRoot!.querySelector<HTMLElement>(".confirm")!;
    setTimeout(() => confirm.click());
    await oneEvent(el, "fluid-confirm");
    expect(el.open).to.be.false;
  });

  it("fires fluid-cancel and closes when cancel is clicked", async () => {
    const el = await fixture<FluidPopconfirm>(html`
      <fluid-popconfirm><fluid-button slot="trigger">X</fluid-button></fluid-popconfirm>
    `);
    await open(el);
    const cancel = el.shadowRoot!.querySelector<HTMLElement>(".cancel")!;
    setTimeout(() => cancel.click());
    await oneEvent(el, "fluid-cancel");
    expect(el.open).to.be.false;
  });

  it("cancels on Escape", async () => {
    const el = await fixture<FluidPopconfirm>(html`
      <fluid-popconfirm><fluid-button slot="trigger">X</fluid-button></fluid-popconfirm>
    `);
    await open(el);
    setTimeout(() => document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape" })));
    await oneEvent(el, "fluid-cancel");
    expect(el.open).to.be.false;
  });

  it("does not open when disabled", async () => {
    const el = await fixture<FluidPopconfirm>(html`
      <fluid-popconfirm disabled><fluid-button slot="trigger">X</fluid-button></fluid-popconfirm>
    `);
    await open(el);
    expect(el.open).to.be.false;
  });

  it("reflects custom labels onto the buttons", async () => {
    const el = await fixture<FluidPopconfirm>(html`
      <fluid-popconfirm confirm-text="Yep" cancel-text="Nope">
        <fluid-button slot="trigger">X</fluid-button>
      </fluid-popconfirm>
    `);
    await elementUpdated(el);
    expect(el.shadowRoot!.querySelector(".confirm")!.textContent?.trim()).to.equal("Yep");
    expect(el.shadowRoot!.querySelector(".cancel")!.textContent?.trim()).to.equal("Nope");
  });

  it("does not fire fluid-hide on initial mount of a closed popconfirm", async () => {
    let hideFired = false;
    const el = await fixture<FluidPopconfirm>(html`
      <fluid-popconfirm><fluid-button slot="trigger">X</fluid-button></fluid-popconfirm>
    `);
    el.addEventListener("fluid-hide", () => {
      hideFired = true;
    });
    // Force the first updated() with the default open=false to flush.
    await elementUpdated(el);
    await aTimeout(20);
    expect(hideFired).to.be.false;
  });

  it("fires fluid-hide on a genuine open->closed transition", async () => {
    const el = await fixture<FluidPopconfirm>(html`
      <fluid-popconfirm><fluid-button slot="trigger">X</fluid-button></fluid-popconfirm>
    `);
    await open(el);
    setTimeout(() => el.hide());
    await oneEvent(el, "fluid-hide");
    expect(el.open).to.be.false;
  });

  it("traps Tab focus inside the modal alertdialog", async () => {
    const el = await fixture<FluidPopconfirm>(html`
      <fluid-popconfirm><fluid-button slot="trigger">X</fluid-button></fluid-popconfirm>
    `);
    await open(el);
    const cancel = el.shadowRoot!.querySelector<HTMLElement>(".cancel")!;
    const confirm = el.shadowRoot!.querySelector<HTMLElement>(".confirm")!;

    // From the last control, Tab wraps back to the first (Cancel).
    confirm.focus();
    document.dispatchEvent(new KeyboardEvent("keydown", { key: "Tab", bubbles: true }));
    await elementUpdated(el);
    expect(el.shadowRoot!.activeElement).to.equal(cancel);

    // From the first control, Shift+Tab wraps to the last (Confirm).
    cancel.focus();
    document.dispatchEvent(
      new KeyboardEvent("keydown", { key: "Tab", shiftKey: true, bubbles: true })
    );
    await elementUpdated(el);
    expect(el.shadowRoot!.activeElement).to.equal(confirm);
  });

  it("passes a11y audit when open", async () => {
    const wrapper = await fixture<HTMLDivElement>(html`
      <div style=${TOKENS}>
        <fluid-popconfirm message="Delete this?" confirm-text="Delete">
          <fluid-button slot="trigger" variant="secondary" tone="danger">Delete</fluid-button>
        </fluid-popconfirm>
      </div>
    `);
    const el = wrapper.querySelector<FluidPopconfirm>("fluid-popconfirm")!;
    await open(el);
    await expect(el).to.be.accessible();
  });
});
