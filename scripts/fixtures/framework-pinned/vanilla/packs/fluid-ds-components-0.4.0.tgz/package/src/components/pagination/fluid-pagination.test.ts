import { expect, fixture, html, oneEvent, elementUpdated, aTimeout } from "@open-wc/testing";
import "./define.js";
import type { FluidPagination } from "./fluid-pagination.js";

const pageButtons = (el: FluidPagination) =>
  Array.from(el.shadowRoot!.querySelectorAll<HTMLButtonElement>("button.page"));

const prevButton = (el: FluidPagination) =>
  el.shadowRoot!.querySelector<HTMLButtonElement>('button[part~="prev"]')!;

const nextButton = (el: FluidPagination) =>
  el.shadowRoot!.querySelector<HTMLButtonElement>('button[part~="next"]')!;

describe("<fluid-pagination>", () => {
  it("renders a labelled navigation landmark", async () => {
    const el = await fixture<FluidPagination>(
      html`<fluid-pagination total-pages="5"></fluid-pagination>`
    );
    const nav = el.shadowRoot!.querySelector("nav")!;
    expect(nav).to.exist;
    expect(nav.getAttribute("aria-label")).to.equal("Pagination");
  });

  it("honors a custom label", async () => {
    const el = await fixture<FluidPagination>(
      html`<fluid-pagination total-pages="5" label="Results"></fluid-pagination>`
    );
    expect(el.shadowRoot!.querySelector("nav")!.getAttribute("aria-label")).to.equal("Results");
  });

  it("derives page count from total and page-size", async () => {
    const el = await fixture<FluidPagination>(
      html`<fluid-pagination total="45" page-size="10"></fluid-pagination>`
    );
    // 45 / 10 = 5 pages. Small list shows every page.
    expect(pageButtons(el).map((b) => b.textContent?.trim())).to.deep.equal([
      "1",
      "2",
      "3",
      "4",
      "5"
    ]);
  });

  it("total-pages takes precedence over total", async () => {
    const el = await fixture<FluidPagination>(
      html`<fluid-pagination total="999" page-size="10" total-pages="3"></fluid-pagination>`
    );
    expect(pageButtons(el)).to.have.lengthOf(3);
  });

  it("marks the current page with aria-current and no other", async () => {
    const el = await fixture<FluidPagination>(
      html`<fluid-pagination total-pages="5" page="3"></fluid-pagination>`
    );
    const current = pageButtons(el).filter((b) => b.getAttribute("aria-current") === "page");
    expect(current).to.have.lengthOf(1);
    expect(current[0]!.textContent?.trim()).to.equal("3");
  });

  it("truncates a long list with ellipses around the current page", async () => {
    const el = await fixture<FluidPagination>(
      html`<fluid-pagination total-pages="20" page="10"></fluid-pagination>`
    );
    const ellipses = el.shadowRoot!.querySelectorAll('[part~="ellipsis"]');
    expect(ellipses).to.have.lengthOf(2);
    // First and last page always rendered.
    const labels = pageButtons(el).map((b) => b.textContent?.trim());
    expect(labels[0]).to.equal("1");
    expect(labels[labels.length - 1]).to.equal("20");
    expect(labels).to.include("10");
  });

  it("disables Previous on the first page", async () => {
    const el = await fixture<FluidPagination>(
      html`<fluid-pagination total-pages="10" page="1"></fluid-pagination>`
    );
    expect(prevButton(el).disabled).to.be.true;
    expect(nextButton(el).disabled).to.be.false;
  });

  it("disables Next on the last page", async () => {
    const el = await fixture<FluidPagination>(
      html`<fluid-pagination total-pages="10" page="10"></fluid-pagination>`
    );
    expect(nextButton(el).disabled).to.be.true;
    expect(prevButton(el).disabled).to.be.false;
  });

  it("aligns the Previous/Next controls with the page numbers under an inherited line-height", async () => {
    /* The ambient line-height matters: the buttons use `font: inherit`, so a
       page that sets a roomy line-height used to hand it to the button text, so
       a number button grew a font-size x line-height text box while the
       icon-only Previous/Next stayed on the 24px target-size floor, leaving
       them visibly off-centre. */
    const holder = await fixture<HTMLDivElement>(html`
      <div style="line-height: 1.8; font-size: 18px">
        <fluid-pagination total-pages="5" page="3"></fluid-pagination>
      </div>
    `);
    const el = holder.querySelector<FluidPagination>("fluid-pagination")!;
    await elementUpdated(el);

    const controls = [...el.shadowRoot!.querySelectorAll<HTMLElement>("button")];
    expect(controls.length).to.be.greaterThan(2);

    const heights = controls.map((c) => c.getBoundingClientRect().height);
    const heightSpread = Math.max(...heights) - Math.min(...heights);
    expect(heightSpread, `control heights differ by ${heightSpread.toFixed(2)}px`).to.be.at.most(
      0.5
    );

    const centres = controls.map((c) => {
      const r = c.getBoundingClientRect();
      return r.top + r.height / 2;
    });
    const spread = Math.max(...centres) - Math.min(...centres);
    expect(spread, `controls drift vertically by ${spread.toFixed(2)}px`).to.be.at.most(0.5);
  });

  it("fires fluid-page-change with the target page on a number click", async () => {
    // Small list (no truncation), so page 4 is reliably rendered. Select it by
    // its stable accessible name rather than visible text.
    const el = await fixture<FluidPagination>(
      html`<fluid-pagination total-pages="5" page="1"></fluid-pagination>`
    );
    const fourth = el.shadowRoot!.querySelector<HTMLButtonElement>(
      'button.page[aria-label="Page 4"]'
    )!;
    expect(fourth).to.exist;
    setTimeout(() => fourth.click());
    const event = await oneEvent(el, "fluid-page-change");
    expect(event.detail.page).to.equal(4);
  });

  it("updates the reflected page after navigation", async () => {
    const el = await fixture<FluidPagination>(
      html`<fluid-pagination total-pages="10" page="1"></fluid-pagination>`
    );
    nextButton(el).click();
    await elementUpdated(el);
    expect(el.page).to.equal(2);
    expect(el.getAttribute("page")).to.equal("2");
  });

  it("Previous and Next move by one page", async () => {
    const el = await fixture<FluidPagination>(
      html`<fluid-pagination total-pages="10" page="5"></fluid-pagination>`
    );
    setTimeout(() => prevButton(el).click());
    const prevEvent = await oneEvent(el, "fluid-page-change");
    expect(prevEvent.detail.page).to.equal(4);

    el.page = 5;
    await elementUpdated(el);
    setTimeout(() => nextButton(el).click());
    const nextEvent = await oneEvent(el, "fluid-page-change");
    expect(nextEvent.detail.page).to.equal(6);
  });

  it("does not fire when clicking the current page", async () => {
    const el = await fixture<FluidPagination>(
      html`<fluid-pagination total-pages="10" page="3"></fluid-pagination>`
    );
    let fired = false;
    el.addEventListener("fluid-page-change", () => (fired = true));
    pageButtons(el)
      .find((b) => b.getAttribute("aria-current") === "page")!
      .click();
    expect(fired).to.be.false;
  });

  it("clamps an out-of-range page into the valid range", async () => {
    const el = await fixture<FluidPagination>(
      html`<fluid-pagination total-pages="5" page="99"></fluid-pagination>`
    );
    await elementUpdated(el);
    expect(el.page).to.equal(5);
  });

  it("normalizes non-finite totals before building page controls", () => {
    const el = document.createElement("fluid-pagination") as FluidPagination;
    el.totalPages = Number.POSITIVE_INFINITY;
    const pageCount = (el as unknown as { pageCount: number }).pageCount;
    // Restore a finite value before Lit's queued initial render runs.
    el.totalPages = 1;
    expect(pageCount).to.equal(1);
  });

  it("reconciles invalid live totals and current-page mutations", async () => {
    const el = await fixture<FluidPagination>(
      html`<fluid-pagination total-pages="10" page="10"></fluid-pagination>`
    );
    el.totalPages = -4;
    el.page = Number.NaN;
    await el.updateComplete;
    expect(el.page).to.equal(1);
    expect(pageButtons(el).map((button) => button.textContent?.trim())).to.deep.equal(["1"]);
    expect(prevButton(el).disabled).to.equal(true);
    expect(nextButton(el).disabled).to.equal(true);
  });

  it("keeps controls operable when embedded in a form", async () => {
    const form = await fixture<HTMLFormElement>(html`
      <form>
        <fluid-pagination total-pages="3"></fluid-pagination>
      </form>
    `);
    const el = form.querySelector<FluidPagination>("fluid-pagination")!;
    let submits = 0;
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      submits++;
    });
    nextButton(el).click();
    await el.updateComplete;
    expect(submits).to.equal(0);
    expect(el.page).to.equal(2);
    expect(
      Array.from(el.shadowRoot!.querySelectorAll("button")).every(
        (button) => button.type === "button"
      )
    ).to.equal(true);
  });

  it("updates edge direction after a live RTL mutation", async () => {
    const wrapper = await fixture<HTMLDivElement>(html`
      <div dir="ltr"><fluid-pagination total-pages="3" page="2"></fluid-pagination></div>
    `);
    const el = wrapper.querySelector<FluidPagination>("fluid-pagination")!;
    const previousPath = () => prevButton(el).querySelector("path")?.getAttribute("d") ?? "";
    const ltrPath = previousPath();
    wrapper.dir = "rtl";
    await new Promise((resolve) => setTimeout(resolve, 0));
    await el.updateComplete;
    expect(previousPath()).to.not.equal(ltrPath);
  });

  it("allows its control list to reflow in narrow containers", async () => {
    const el = await fixture<FluidPagination>(
      html`<fluid-pagination
        style="inline-size: 8rem"
        total-pages="20"
        page="10"
      ></fluid-pagination>`
    );
    const list = el.shadowRoot!.querySelector<HTMLElement>(".list")!;
    expect(getComputedStyle(list).flexWrap).to.equal("wrap");
  });

  it("each page button exposes an accessible name", async () => {
    const el = await fixture<FluidPagination>(
      html`<fluid-pagination total-pages="5" page="1"></fluid-pagination>`
    );
    expect(pageButtons(el)[0]!.getAttribute("aria-label")).to.equal("Page 1");
    expect(prevButton(el).getAttribute("aria-label")).to.equal("Previous page");
    expect(nextButton(el).getAttribute("aria-label")).to.equal("Next page");
  });

  it("passes a11y audit", async () => {
    const el = await fixture<FluidPagination>(html`
      <div
        style="
          --fluid-surface-base:#ffffff;
          --fluid-surface-muted:#f4f4f5;
          --fluid-text-primary:#18181b;
          --fluid-text-secondary:#3f3f46;
          --fluid-border-default:#e4e4e7;
          --fluid-accent-base:#4f46e5;
          --fluid-accent-text:#ffffff;
        "
      >
        <fluid-pagination total-pages="20" page="10"></fluid-pagination>
      </div>
    `);
    const pagination = el.querySelector<FluidPagination>("fluid-pagination")!;
    await elementUpdated(pagination);
    await aTimeout(20);
    await expect(pagination).to.be.accessible();
  });
});
