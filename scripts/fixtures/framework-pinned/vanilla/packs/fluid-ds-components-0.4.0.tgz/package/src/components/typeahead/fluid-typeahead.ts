import { html, css, type PropertyValues, type TemplateResult } from "lit";
import { property, query, state } from "lit/decorators.js";
import { classMap } from "lit/directives/class-map.js";
import { ifDefined } from "lit/directives/if-defined.js";
import { live } from "lit/directives/live.js";
import { autoUpdate, computePosition, flip, offset, size } from "../../internal/position.js";
import { FluidFormAssociated } from "../../internal/form-associated.js";
import {
  fieldChromeStyles,
  fieldHelpDescribedBy,
  renderFieldChrome
} from "../../internal/field-chrome.js";
import { hideFromTopLayer, showInTopLayer } from "../../internal/top-layer.js";

let counter = 0;

/**
 * One option, normalized from any of the four supported input paths.
 */
export interface TypeaheadOption {
  value: string;
  label: string;
  /** Free-form payload, preserved through events so consumers can read it. */
  data?: unknown;
}

export interface FluidTypeaheadInputDetail {
  value: string;
}
export interface FluidTypeaheadChangeDetail {
  value: string;
  label: string;
  option: TypeaheadOption;
}
export type FluidTypeaheadInputEvent = CustomEvent<FluidTypeaheadInputDetail>;
export type FluidTypeaheadChangeEvent = CustomEvent<FluidTypeaheadChangeDetail>;

type RawOption = string | TypeaheadOption;

/**
 * What a row renderer is told about the row it is drawing.
 */
export interface TypeaheadOptionContext {
  /** Position in the filtered list. */
  index: number;
  /** True while the row is the keyboard-active one. */
  active: boolean;
  /** True when the row is the current value. */
  selected: boolean;
  /** The current query, already trimmed. */
  query: string;
  /**
   * Marks the query inside a piece of text, the same way the default row does.
   * A custom row usually still wants the match highlighted somewhere.
   */
  highlight: (text: string) => TemplateResult;
}

/** Draws one option row. Anything Lit can render is accepted. */
export type TypeaheadOptionRenderer = (
  option: TypeaheadOption,
  context: TypeaheadOptionContext
) => TemplateResult | string;

/**
 * An autocomplete / typeahead input.
 *
 * Four ways to feed it options:
 *
 * 1. **Property (array)**: for React/Vue/Lit consumers with dynamic data:
 *    ```html
 *    <fluid-typeahead .options=${["Apple","Banana"]}></fluid-typeahead>
 *    ```
 *
 * 2. **JSON-string attribute**: for vanilla HTML with static data:
 *    ```html
 *    <fluid-typeahead options='["Apple","Banana"]'></fluid-typeahead>
 *    ```
 *
 * 3. **Async loader**: for remote suggestions; called with the current query
 *    (debounced via the `debounce` attribute):
 *    ```html
 *    <fluid-typeahead .loadOptions=${async (q) => fetch(...)}></fluid-typeahead>
 *    ```
 *
 * 4. **Slotted children**: for richer option markup:
 *    ```html
 *    <fluid-typeahead>
 *      <fluid-option value="us">United States</fluid-option>
 *    </fluid-typeahead>
 *    ```
 *
 * Set `keep-open` to gather several values: the list stays open after a choice
 * and the query is left alone, with each pick reported through `fluid-change`.
 *
 * Options supplied as data render as a highlighted label. Pass `renderOption`
 * to draw the row yourself: checkboxes, trailing metadata, avatars, anything.
 * The row is a flex container, so `margin-inline-start: auto` right-aligns a
 * trailing element.
 *
 * Implements the WAI-ARIA combobox pattern. Form-associated.
 *
 * @summary Autocomplete text input.
 *
 * @slot - Optional `<fluid-option>` children with extra markup.
 *
 *
 * A visible label and help text can be attached directly with the `label` and
 * `help-text` attributes; the label is a real `<label for>` inside the shadow
 * root and the help text is announced via `aria-describedby`. For rich label
 * content, error messages, or a required indicator, wrap the control in
 * `fluid-field` instead.
 *
 * @csspart label - The visible label (present only when `label` is set).
 * @csspart help-text - The help text (present only when `help-text` is set).
 * @csspart base - The outer wrapper.
 * @csspart input - The text input.
 * @csspart listbox - The popover listbox.
 * @csspart option - Each option row.
 *
 * Every styled property reads a component-scoped `--fluid-typeahead-*` token
 * that falls back to a main semantic var (the override ladder), most fall
 * through to the shared `--fluid-field-*` tokens so a typeahead matches your
 * inputs by default.
 *
 * @cssproperty --fluid-typeahead-bg - Input and listbox background. Falls back to --fluid-surface-base.
 * @cssproperty --fluid-typeahead-fg - Input and option text color. Falls back to --fluid-text-primary.
 * @cssproperty --fluid-typeahead-border - Default border color. Falls back to --fluid-border-default.
 * @cssproperty --fluid-typeahead-border-hover - Border color on hover. Falls back to --fluid-border-strong.
 * @cssproperty --fluid-typeahead-border-focus - Border color when focused / open. Falls back to --fluid-accent-base.
 * @cssproperty --fluid-typeahead-border-width - Border width. Falls back to --fluid-field-border-width.
 * @cssproperty --fluid-typeahead-radius - Corner radius. Falls back to --fluid-field-border-radius.
 * @cssproperty --fluid-typeahead-font-family - Font family. Falls back to --fluid-font-family-sans.
 * @cssproperty --fluid-typeahead-focus-ring - Focus ring color. Falls back to --fluid-focus-ring-color.
 * @cssproperty --fluid-typeahead-focus-ring-width - Focus ring width. Falls back to --fluid-focus-ring-width.
 * @cssproperty --fluid-typeahead-disabled-bg - Disabled state background. Falls back to --fluid-surface-subtle.
 * @cssproperty --fluid-typeahead-disabled-fg - Disabled state foreground. Falls back to --fluid-text-secondary.
 * @cssproperty --fluid-typeahead-placeholder-fg - Placeholder text color. Falls back to --fluid-text-secondary.
 * @cssproperty --fluid-typeahead-accent - Accent used for active rail, match highlight, selected text. Falls back to --fluid-accent-base.
 * @cssproperty --fluid-typeahead-empty-fg - Empty/loading text color. Falls back to --fluid-text-secondary.
 * @cssproperty --fluid-typeahead-listbox-shadow - Listbox elevation. Falls back to --fluid-shadow-lg.
 * @cssproperty --fluid-typeahead-invalid-border - Invalid border color. Falls back to --fluid-danger-base.
 * @cssproperty --fluid-typeahead-duration - Transition duration. Falls back to --fluid-duration-fast.
 * @cssproperty --fluid-typeahead-easing - Transition easing. Falls back to --fluid-easing-standard.
 * @cssproperty --fluid-typeahead-height-sm - Small field height. Falls back to --fluid-field-height-sm.
 * @cssproperty --fluid-typeahead-height-md - Medium field height. Falls back to --fluid-field-height-md.
 * @cssproperty --fluid-typeahead-height-lg - Large field height. Falls back to --fluid-field-height-lg.
 * @cssproperty --fluid-typeahead-font-size-sm - Small text size. Falls back to --fluid-font-size-sm.
 * @cssproperty --fluid-typeahead-font-size-md - Medium text size. Falls back to --fluid-font-size-md.
 * @cssproperty --fluid-typeahead-font-size-lg - Large text size. Falls back to --fluid-font-size-lg.
 * @cssproperty --fluid-typeahead-padding-x-sm - Small inline padding. Falls back to --fluid-field-padding-x-sm.
 * @cssproperty --fluid-typeahead-padding-x-md - Medium inline padding. Falls back to --fluid-field-padding-x-md.
 * @cssproperty --fluid-typeahead-padding-x-lg - Large inline padding. Falls back to --fluid-field-padding-x-lg.
 * @cssproperty --fluid-typeahead-listbox-padding - Listbox padding. Falls back to --fluid-space-1.
 * @cssproperty --fluid-typeahead-listbox-max-height - Listbox maximum height. Defaults to 18rem.
 * @cssproperty --fluid-typeahead-option-padding-block - Option block padding. Falls back to --fluid-space-2.
 * @cssproperty --fluid-typeahead-option-padding-inline - Option inline padding. Falls back to --fluid-space-3.
 * @cssproperty --fluid-typeahead-option-radius - Option radius. Falls back to --fluid-radius-sm.
 * @cssproperty --fluid-typeahead-option-active-bg - Active option background.
 * @cssproperty --fluid-typeahead-option-active-rail-width - Active rail width. Defaults to 2px.
 * @cssproperty --fluid-typeahead-option-active-rail-inset - Active rail block inset. Defaults to 4px.
 * @cssproperty --fluid-typeahead-option-selected-font-weight - Selected option weight. Falls back to --fluid-font-weight-semibold.
 *
 * @uses-token --fluid-surface-base - Input + listbox background.
 * @uses-token --fluid-surface-subtle - Disabled background.
 * @uses-token --fluid-border-default - Default borders.
 * @uses-token --fluid-border-strong - Border on hover.
 * @uses-token --fluid-accent-base - Focused state + highlight.
 * @uses-token --fluid-text-primary - Input + option text.
 * @uses-token --fluid-text-secondary - Placeholder, disabled, empty text.
 * @uses-token --fluid-focus-ring-color - Keyboard focus indicator color.
 * @uses-token --fluid-focus-ring-width - Focus ring width (2px AA / 3px AAA).
 * @uses-token --fluid-target-min - Minimum field height floor (24px AA / 44px AAA).
 * @uses-token --fluid-field-border-width - Default border width.
 * @uses-token --fluid-field-border-radius - Default corner radius.
 * @uses-token --fluid-field-height-sm - Field height at size="sm".
 * @uses-token --fluid-field-height-md - Field height at size="md".
 * @uses-token --fluid-field-height-lg - Field height at size="lg".
 * @uses-token --fluid-font-family-sans - Input font family.
 * @uses-token --fluid-shadow-lg - Listbox elevation.
 *
 * @fires {FluidTypeaheadInputEvent} fluid-input - Fired on every keystroke. detail.value is the current query.
 * @fires {FluidTypeaheadChangeEvent} fluid-change - Fired when an option is selected. detail.option is the chosen TypeaheadOption.
 */
export class FluidTypeahead extends FluidFormAssociated {
  // Native constraint validation must be able to focus the shadow control.
  static override shadowRootOptions: ShadowRootInit = {
    ...FluidFormAssociated.shadowRootOptions,
    delegatesFocus: true
  };

  static override formAssociated = true;

  static override styles = [
    fieldChromeStyles,
    css`
      :host {
        display: inline-flex;
        width: 100%;
        max-width: 100%;
      }

      .base {
        position: relative;
        width: 100%;
      }

      .input-wrap {
        display: inline-flex;
        align-items: stretch;
        width: 100%;
        background: var(--fluid-typeahead-bg, var(--fluid-surface-base));
        border: var(--fluid-typeahead-border-width, var(--fluid-field-border-width)) solid
          var(--fluid-typeahead-border, var(--fluid-border-default));
        border-radius: var(--fluid-typeahead-radius, var(--fluid-field-border-radius));
        box-shadow:
          inset 0 1px 0 0 rgb(0 0 0 / 0.02),
          0 1px 2px 0 rgb(0 0 0 / 0.04);
        transition:
          border-color var(--fluid-typeahead-duration, var(--fluid-duration-fast))
            var(--fluid-typeahead-easing, var(--fluid-easing-standard)),
          box-shadow var(--fluid-typeahead-duration, var(--fluid-duration-fast))
            var(--fluid-typeahead-easing, var(--fluid-easing-standard));
        font-family: var(--fluid-typeahead-font-family, var(--fluid-font-family-sans));
        color: var(--fluid-typeahead-fg, var(--fluid-text-primary));
        overflow: hidden;
      }

      /*
     * Prefix / suffix render as flush sibling sections of the field, divided
     * by a rule — the same treatment fluid-input gives them, so a typeahead
     * and an input carrying the same affix look identical.
     */
      .affix {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        align-self: stretch;
        flex-shrink: 0;
        color: var(--fluid-typeahead-affix-fg, var(--fluid-text-secondary));
        background: var(--fluid-typeahead-affix-bg, var(--fluid-surface-subtle));
      }
      .affix[hidden] {
        display: none;
      }
      .prefix {
        border-inline-end: var(--fluid-typeahead-border-width, var(--fluid-field-border-width))
          solid var(--fluid-typeahead-affix-border, var(--fluid-border-default));
      }
      .suffix {
        border-inline-start: var(--fluid-typeahead-border-width, var(--fluid-field-border-width))
          solid var(--fluid-typeahead-affix-border, var(--fluid-border-default));
      }
      .size-sm .affix:not(.flush) {
        padding: 0 var(--fluid-typeahead-padding-x-sm, var(--fluid-field-padding-x-sm));
      }
      .size-md .affix:not(.flush) {
        padding: 0 var(--fluid-typeahead-padding-x-md, var(--fluid-field-padding-x-md));
      }
      .size-lg .affix:not(.flush) {
        padding: 0 var(--fluid-typeahead-padding-x-lg, var(--fluid-field-padding-x-lg));
      }
      /*
     * data-flush: an affix that is itself a control (a select, a swatch) owns
     * its own padding, so the wrapper gives up its own and lets it stretch.
     */
      .affix.flush {
        padding: 0;
        align-items: stretch;
      }

      .input-wrap:hover:not(.disabled):not(.focused) {
        border-color: var(--fluid-typeahead-border-hover, var(--fluid-border-strong));
      }

      .input-wrap.focused {
        border-color: var(--fluid-typeahead-border-focus, var(--fluid-accent-base));
        box-shadow:
          0 0 0 var(--fluid-typeahead-focus-ring-width, var(--fluid-focus-ring-width))
            color-mix(
              in srgb,
              var(--fluid-typeahead-focus-ring, var(--fluid-focus-ring-color)) 25%,
              transparent
            ),
          inset 0 1px 0 0 rgb(0 0 0 / 0.02);
      }

      .input-wrap.disabled {
        background: var(--fluid-typeahead-disabled-bg, var(--fluid-surface-subtle));
        color: var(--fluid-typeahead-disabled-fg, var(--fluid-text-secondary));
        cursor: not-allowed;
      }

      .input-wrap.invalid {
        border-color: var(--fluid-typeahead-invalid-border, var(--fluid-danger-base));
      }
      .input-wrap.invalid.focused {
        box-shadow: 0 0 0 var(--fluid-typeahead-focus-ring-width, var(--fluid-focus-ring-width))
          color-mix(
            in srgb,
            var(--fluid-typeahead-invalid-border, var(--fluid-danger-base)) 35%,
            transparent
          );
      }

      /* Fused-dropdown styling, see fluid-select for the same pattern.
       When open, the listbox visually grows out of the input as one shape:
       seam edge is flat, halo wraps three sides, listbox borrows the same
       accent border to read as one element. */
      :host([open][data-placement="bottom"]) .input-wrap {
        border-bottom-left-radius: 0;
        border-bottom-right-radius: 0;
      }
      /*
     * Drop the focus halo entirely when fused. The accent border on the
     * combined shape already signals focus clearly; the extra halo around the
     * input alone reads as a visual gap between input and listbox.
     */
      :host([open]) .input-wrap.focused {
        box-shadow: inset 0 1px 0 0 rgb(0 0 0 / 0.02);
      }
      :host([open][data-placement="top"]) .input-wrap {
        border-top-left-radius: 0;
        border-top-right-radius: 0;
      }

      /*
     * SC 2.5.8 Target Size. min-height reads --fluid-target-min as a floor so
     * AAA (44px) lifts the field without touching the visual padding; AA stays
     * at the field height. Literal fallbacks keep the max() valid when the
     * field-height tokens aren't loaded (e.g. unit tests).
     */
      .size-sm {
        min-height: max(
          var(--fluid-typeahead-height-sm, var(--fluid-field-height-sm, 1.75rem)),
          var(--fluid-target-min, 0px)
        );
        font-size: var(--fluid-typeahead-font-size-sm, var(--fluid-font-size-sm));
      }
      .size-md {
        min-height: max(
          var(--fluid-typeahead-height-md, var(--fluid-field-height-md, 2.25rem)),
          var(--fluid-target-min, 0px)
        );
        font-size: var(--fluid-typeahead-font-size-md, var(--fluid-font-size-md));
      }
      .size-lg {
        min-height: max(
          var(--fluid-typeahead-height-lg, var(--fluid-field-height-lg, 2.75rem)),
          var(--fluid-target-min, 0px)
        );
        font-size: var(--fluid-typeahead-font-size-lg, var(--fluid-font-size-lg));
      }

      input {
        all: unset;
        flex: 1 1 auto;
        min-width: 0;
        font: inherit;
        color: inherit;
        line-height: var(--fluid-typeahead-line-height, var(--fluid-font-line-height-normal));
      }
      .size-sm input {
        padding: 0 var(--fluid-typeahead-padding-x-sm, var(--fluid-field-padding-x-sm));
      }
      .size-md input {
        padding: 0 var(--fluid-typeahead-padding-x-md, var(--fluid-field-padding-x-md));
      }
      .size-lg input {
        padding: 0 var(--fluid-typeahead-padding-x-lg, var(--fluid-field-padding-x-lg));
      }
      input::placeholder {
        color: var(--fluid-typeahead-placeholder-fg, var(--fluid-text-secondary));
      }

      /*
     * The Popover API promotes the listbox to the browser top layer so cards,
     * modals and transformed containers cannot clip it. position:fixed and
     * the positioning engine still owns viewport placement and provide the fallback.
     */
      .listbox {
        position: fixed;
        inset: auto;
        margin: 0;
        top: 0;
        left: 0;
        z-index: 1000;
        box-sizing: border-box;
        max-height: var(--fluid-typeahead-listbox-max-height, 18rem);
        overflow: hidden auto;
        background: var(--fluid-typeahead-bg, var(--fluid-surface-base));
        border: var(--fluid-typeahead-border-width, var(--fluid-field-border-width)) solid
          var(--fluid-typeahead-border, var(--fluid-border-default));
        border-radius: var(--fluid-typeahead-radius, var(--fluid-field-border-radius));
        box-shadow: var(--fluid-typeahead-listbox-shadow, var(--fluid-shadow-lg));
        padding: var(--fluid-typeahead-listbox-padding, var(--fluid-space-1));
        opacity: 0;
        visibility: hidden;
        transition:
          opacity var(--fluid-typeahead-duration, var(--fluid-duration-fast))
            var(--fluid-typeahead-easing, var(--fluid-easing-standard)),
          visibility 0s var(--fluid-typeahead-duration, var(--fluid-duration-fast));
      }

      :host([open]) .listbox {
        opacity: 1;
        visibility: visible;
        transition-delay: 0s;
        border-color: var(--fluid-typeahead-border-focus, var(--fluid-accent-base));
      }

      :host([open][data-placement="bottom"]) .listbox {
        border-top: 0;
        border-top-left-radius: 0;
        border-top-right-radius: 0;
      }
      :host([open][data-placement="top"]) .listbox {
        border-bottom: 0;
        border-bottom-left-radius: 0;
        border-bottom-right-radius: 0;
      }

      .option {
        display: flex;
        align-items: center;
        padding: var(--fluid-typeahead-option-padding-block, var(--fluid-space-2))
          var(--fluid-typeahead-option-padding-inline, var(--fluid-space-3));
        cursor: pointer;
        user-select: none;
        border-radius: var(--fluid-typeahead-option-radius, var(--fluid-radius-sm));
        font-size: inherit;
        color: var(--fluid-typeahead-fg, var(--fluid-text-primary));
        position: relative;
        transition:
          background-color var(--fluid-typeahead-duration, var(--fluid-duration-fast))
            var(--fluid-typeahead-easing, var(--fluid-easing-standard)),
          color var(--fluid-typeahead-duration, var(--fluid-duration-fast))
            var(--fluid-typeahead-easing, var(--fluid-easing-standard));
      }

      /*
     * Active = keyboard-focused option. Brand-tinted background with a 2px
     * accent rail on the left edge, more identifiable than a flat grey row,
     * and the rail visually anchors the highlight to the brand.
     */
      .option.active {
        background: var(
          --fluid-typeahead-option-active-bg,
          color-mix(
            in srgb,
            var(--fluid-typeahead-accent, var(--fluid-accent-base)) 8%,
            transparent
          )
        );
        color: var(--fluid-typeahead-fg, var(--fluid-text-primary));
      }
      .option.active::before {
        content: "";
        position: absolute;
        inset-inline-start: 0;
        top: var(--fluid-typeahead-option-active-rail-inset, 4px);
        bottom: var(--fluid-typeahead-option-active-rail-inset, 4px);
        width: var(--fluid-typeahead-option-active-rail-width, 2px);
        background: var(--fluid-typeahead-accent, var(--fluid-accent-base));
        border-radius: var(--fluid-typeahead-option-active-rail-radius, var(--fluid-radius-full));
      }

      .option.selected {
        color: var(--fluid-typeahead-accent, var(--fluid-accent-base));
        font-weight: var(
          --fluid-typeahead-option-selected-font-weight,
          var(--fluid-font-weight-semibold)
        );
      }

      .option-empty,
      .option-loading {
        padding: var(--fluid-typeahead-empty-padding, var(--fluid-space-3));
        color: var(--fluid-typeahead-empty-fg, var(--fluid-text-secondary));
        font-size: var(--fluid-typeahead-empty-font-size, var(--fluid-font-size-sm));
        text-align: center;
      }

      /*
     * Match highlight, the matched substring inside an option's label.
     * Weight bump + accent color, no extra background, so it composes cleanly
     * with the active-row tint instead of fighting it.
     */
      .match {
        color: var(--fluid-typeahead-accent, var(--fluid-accent-base));
        font-weight: var(--fluid-typeahead-match-font-weight, var(--fluid-font-weight-semibold));
      }
      .option.active .match,
      .option.selected .match {
        color: inherit;
      }
    `
  ];

  @query("input") private inputEl!: HTMLInputElement;
  @query(".input-wrap") private wrapEl!: HTMLElement;
  @query(".listbox") private listboxEl!: HTMLElement;

  /**
   * Options. Accepts either a JS array (set via property: `.options=[...]`)
   * OR a JSON-encoded string (set via attribute: `options='[...]'`).
   * Lit handles both transparently because `type: Array` parses string
   * attributes as JSON.
   */
  @property({ type: Array }) options: RawOption[] = [];

  /**
   * Async loader. Called with the current query string after `debounce` ms.
   * Must return an array of options (or a Promise of one). Overrides the
   * static `options` prop when set.
   */
  @property({ attribute: false }) loadOptions?: (
    query: string
  ) => Promise<RawOption[]> | RawOption[];

  /** Debounce delay (ms) for loadOptions calls. */
  @property({ type: Number, attribute: "debounce" }) debounceMs = 200;

  /** Minimum query length before opening + loading. */
  @property({ type: Number, attribute: "min-query" }) minQuery = 0;

  /** Maximum number of options shown in the listbox (after filtering). */
  @property({ type: Number, attribute: "max-options" }) maxOptions = 50;

  /**
   * Draws each option row, replacing the default highlighted label.
   *
   * Options fed as data are the only ones that could not carry their own
   * markup: a slotted `<fluid-option>` may contain anything, while an array or
   * an async loader could only ever supply a string. That left rows built by
   * pasting fields into one label with separators, which cannot align a value
   * to the right, cannot carry a checkbox, and reads as one run of text to a
   * screen reader.
   *
   * The row is a flex container, so `margin-inline-start: auto` on a trailing
   * element pushes it to the end.
   *
   * ```ts
   * .renderOption=${(option, { highlight }) => html`
   *   <fluid-checkbox ?checked=${picked.has(option.value)}></fluid-checkbox>
   *   ${highlight(option.label)}
   *   <small style="margin-inline-start:auto">${option.data.domain}</small>
   * `}
   * ```
   */
  @property({ attribute: false }) renderOption?: TypeaheadOptionRenderer;

  /**
   * Keeps the list open after a choice, and leaves the query alone.
   *
   * A combobox closes on select because picking one value is the whole
   * interaction. A picker that gathers several is a different thing: closing
   * after every pick makes the user reopen and retype to add the next one, and
   * replacing the query with the chosen label throws away the search that
   * found it.
   *
   * The chosen value is still reported through `fluid-change` each time, so
   * what is selected stays the consumer's to hold. Pair it with
   * `renderOption` to show that state on the rows.
   */
  @property({ type: Boolean, reflect: true, attribute: "keep-open" }) keepOpen = false;

  /** Current input value. Submitted with the form. */
  @property() override value = "";

  /** Form control name. */
  @property({ reflect: true }) override name = "";

  /** Size. */
  @property({ reflect: true }) size: "sm" | "md" | "lg" = "md";

  /** Placeholder. */
  @property() placeholder = "";

  /** Disabled state. */
  @property({ type: Boolean, reflect: true }) disabled = false;

  /** Required for form submission. */
  @property({ type: Boolean, reflect: true }) required = false;

  /** Open state. */
  @property({ type: Boolean, reflect: true }) open = false;

  /** Accessible label. */
  @property({ attribute: "aria-label" }) override ariaLabel: string | null = null;

  /** Visible label rendered above the field (a real label/for association). */
  @property() label = "";

  /** Help text rendered below the field, announced via aria-describedby. */
  @property({ attribute: "help-text" }) helpText = "";

  /**
   * When true, restricts the input value to an option's value, typing
   * something that doesn't match clears on blur. Default false: free text.
   */
  @property({ type: Boolean, attribute: "strict" }) strict = false;

  @state() private focused = false;
  @state() private invalid = false;
  @state() private hasPrefix = false;
  @state() private hasSuffix = false;
  @state() private prefixFlush = false;
  @state() private suffixFlush = false;
  @state() private activeIndex = -1;
  @state() private filteredOptions: TypeaheadOption[] = [];
  @state() private loading = false;
  @state() private selectedValue: string | null = null;

  private listboxId = `fluid-typeahead-listbox-${++counter}`;
  private cleanupAutoUpdate?: () => void;
  private debounceTimer?: ReturnType<typeof setTimeout>;
  private lastQuery = "";

  constructor() {
    super();
    this.addEventListener("invalid", this.handleInvalid);
  }

  override connectedCallback(): void {
    super.connectedCallback();
    this.listen(document, "pointerdown", this.handleOutsideClick, { capture: true });
  }

  override disconnectedCallback(): void {
    super.disconnectedCallback();
    this.cleanupAutoUpdate?.();
    hideFromTopLayer(this.listboxEl);
    clearTimeout(this.debounceTimer);
  }

  override formResetCallback(): void {
    this.value = this.getAttribute("value") ?? "";
    this.selectedValue = null;
    this.invalid = false;
  }

  override formDisabledCallback(disabled: boolean): void {
    this.disabled = disabled;
  }

  override formStateRestoreCallback(state: string | File | FormData | null): void {
    if (typeof state === "string") this.value = state;
  }

  override focus(options?: FocusOptions): void {
    this.inputEl?.focus(options);
  }

  /**
   * Normalize a raw option (string or {value,label}) into a TypeaheadOption.
   */
  private normalizeOptions(opts: RawOption[]): TypeaheadOption[] {
    return opts.map((o) =>
      typeof o === "string"
        ? { value: o, label: o }
        : { value: o.value, label: o.label, data: o.data }
    );
  }

  /**
   * Read options from slotted `<fluid-option>` children, if any.
   */
  private slottedOptions(): TypeaheadOption[] {
    const slot = this.shadowRoot?.querySelector<HTMLSlotElement>("slot:not([name])");
    const slotted = slot?.assignedElements({ flatten: true }) ?? [];
    return slotted
      .filter(
        (el): el is HTMLElement & { value: string } =>
          el.tagName.toLowerCase() === "fluid-option" && "value" in el
      )
      .map((el) => ({
        value: el.value,
        label: el.textContent?.trim() ?? el.value
      }));
  }

  protected override willUpdate(changed: PropertyValues<this>): void {
    if (changed.has("value")) {
      this.syncFormValue();
    }
    // Re-filter whenever the value or options change so consumers driving the
    // input via the `value` property see the same filtered list as users
    // typing in the field.
    if ((changed.has("value") || changed.has("options")) && !this.loadOptions) {
      this.recomputeFiltered(this.value);
    }
    // Derive validity before rendering. Updating `invalid` from `updated()`
    // schedules a second reactive pass; when a blurred required control becomes
    // valid, that pass can leave Lit's updateComplete chain unsettled.
    if (this.inputEl) this.refreshValidity();
  }

  protected override updated(changed: PropertyValues<this>): void {
    if (changed.has("open")) {
      if (this.open) this.openListbox();
      else this.closeListbox();
    }
  }

  protected override firstUpdated(): void {
    this.refreshValidity();
  }

  private refreshValidity(showInvalid = this.invalid): void {
    if (this.required && !this.value) {
      this.setValidity({ valueMissing: true }, this.term("fillOutField"), this.inputEl);
      this.invalid = showInvalid;
    } else {
      this.setValidity({});
      this.invalid = false;
    }
  }

  private handleInvalid = () => {
    this.invalid = true;
  };

  private async openListbox(): Promise<void> {
    if (!this.wrapEl || !this.listboxEl) return;
    // Anchor to the input-wrap (the bordered shell) so the listbox aligns
    // with the visible field edge, not the inner native input.
    showInTopLayer(this.listboxEl);
    this.cleanupAutoUpdate = autoUpdate(this.wrapEl, this.listboxEl, () => this.reposition());
    await this.reposition();
    this.scrollActiveIntoView();
  }

  private closeListbox(): void {
    this.cleanupAutoUpdate?.();
    this.cleanupAutoUpdate = undefined;
    hideFromTopLayer(this.listboxEl);
    this.activeIndex = -1;
    this.removeAttribute("data-placement");
  }

  private async reposition(): Promise<void> {
    if (!this.wrapEl || !this.listboxEl) return;
    const { x, y, placement } = await computePosition(this.wrapEl, this.listboxEl, {
      placement: "bottom-start",
      strategy: "fixed",
      middleware: [
        // Sit flush against the input so the two read as a single shape.
        offset(0),
        // Decide flip based on the viewport, not the nearest scrollable card.
        // The viewport is the only boundary that matters: the listbox renders in
        // the top layer, so no ancestor can clip it. Naming
        // document.documentElement as the boundary measured overflow in
        // document coordinates while the reference was measured in viewport
        // ones, so a scrolled page kept the placement it would have had at
        // scroll zero: a control near the bottom of a long page opened
        // upwards even after being scrolled to the top of the screen.
        flip(),
        size({
          apply: ({ rects, elements }) => {
            // Pin width exactly to the input so the fused shape stays aligned.
            elements.floating.style.width = `${rects.reference.width}px`;
          }
        })
      ]
    });
    // Keep the engine's subpixel coords, input + listbox share the same
    // subpixel offset, so they line up. Rounding picks a different pixel
    // grid than the input and shifts the listbox half a pixel sideways.
    Object.assign(this.listboxEl.style, {
      left: `${x}px`,
      top: `${y}px`
    });
    this.setAttribute("data-placement", placement.startsWith("top") ? "top" : "bottom");
  }

  private scrollActiveIntoView(): void {
    if (!this.listboxEl) return;
    const opt = this.listboxEl.querySelectorAll(".option")[this.activeIndex];
    opt?.scrollIntoView({ block: "nearest" });
  }

  private recomputeFiltered(query: string): void {
    if (this.loadOptions) return; // async path handles its own pipeline
    const all = this.options.length ? this.normalizeOptions(this.options) : this.slottedOptions();
    const q = query.trim().toLowerCase();
    const filtered = q ? all.filter((o) => o.label.toLowerCase().includes(q)) : all;
    this.filteredOptions = filtered.slice(0, this.maxOptions);
    this.activeIndex = this.filteredOptions.length ? 0 : -1;
  }

  private scheduleLoad(query: string): void {
    if (!this.loadOptions) return;
    clearTimeout(this.debounceTimer);
    this.debounceTimer = setTimeout(async () => {
      if (query !== this.lastQuery) return;
      this.loading = true;
      try {
        const raw = await this.loadOptions!(query);
        if (query !== this.lastQuery) return; // a newer query has arrived; drop stale result
        this.filteredOptions = this.normalizeOptions(raw).slice(0, this.maxOptions);
        this.activeIndex = this.filteredOptions.length ? 0 : -1;
      } finally {
        this.loading = false;
      }
    }, this.debounceMs);
  }

  private moveActive(delta: number): void {
    const n = this.filteredOptions.length;
    if (!n) return;
    this.activeIndex = (this.activeIndex + delta + n) % n;
    this.scrollActiveIntoView();
  }

  private commitOption(opt: TypeaheadOption): void {
    // Gathering several: the query is what found this row and will find the
    // next one, so it survives, and the list stays where it is.
    if (!this.keepOpen) {
      this.value = opt.label;
      this.open = false;
    }
    this.selectedValue = opt.value;
    this.dispatchEvent(
      new CustomEvent<FluidTypeaheadChangeDetail>("fluid-change", {
        detail: { value: opt.value, label: opt.label, option: opt },
        bubbles: true,
        composed: true
      })
    );
  }

  private handleInput = (e: Event) => {
    const next = (e.target as HTMLInputElement).value;
    this.value = next;
    this.lastQuery = next;
    this.selectedValue = null;
    this.dispatchEvent(
      new CustomEvent<FluidTypeaheadInputDetail>("fluid-input", {
        detail: { value: next },
        bubbles: true,
        composed: true
      })
    );
    if (next.length >= this.minQuery) {
      this.open = true;
      if (this.loadOptions) this.scheduleLoad(next);
      else this.recomputeFiltered(next);
    } else {
      this.open = false;
    }
  };

  /**
   * Brings the list up to date with whatever the value is now.
   *
   * scheduleLoad drops a query that is not the last one typed, which is how a
   * stale result from a slow request is discarded. But the value also changes
   * without being typed — an option is picked, or it is set from outside — and
   * the guard could not tell the two apart, so every refresh after one of those
   * was thrown away and the list stayed on whatever the last keystroke had
   * narrowed it to. Reopening after choosing showed one row: the row already
   * chosen. Announcing the query first is what makes it the current one.
   */
  private refreshOptions(): void {
    if (this.value.length < this.minQuery) return;
    this.lastQuery = this.value;
    if (this.loadOptions) this.scheduleLoad(this.value);
    else this.recomputeFiltered(this.value);
  }

  private handleFocus = () => {
    this.focused = true;
    // Pre-warm the filtered list so the listbox opens instantly when the user
    // hits ArrowDown, but don't auto-open on bare focus (would intrude on
    // tab-through-form flows).
    this.refreshOptions();
  };

  /**
   * A pointer on the field asks to see the choices.
   *
   * Focus alone only pre-warms, because focus also happens on the way past
   * while tabbing through a form and a list opening then would be in the way.
   * A click is not on the way to anywhere, so with a min-query of zero this is
   * what makes the field behave like a select that can also be typed into.
   */
  private handleClick = () => {
    if (this.disabled) return;
    this.refreshOptions();
    if (this.value.length >= this.minQuery) this.open = true;
  };

  private handleBlur = () => {
    this.focused = false;
    if (this.strict && this.selectedValue === null) {
      // Strict mode: invalid free text clears.
      this.value = "";
    }
    this.refreshValidity(true);
  };

  private handleKeyDown = (e: KeyboardEvent) => {
    if (this.disabled) return;
    switch (e.key) {
      case "ArrowDown":
        e.preventDefault();
        if (!this.open) {
          // Opening from the keyboard without leaving the field never passes
          // through focus, so this is the only chance to catch up with a value
          // that changed since the last keystroke.
          this.refreshOptions();
          this.open = true;
          this.activeIndex = this.filteredOptions.length ? 0 : -1;
          this.scrollActiveIntoView();
        } else {
          this.moveActive(1);
        }
        return;
      case "ArrowUp":
        e.preventDefault();
        if (!this.open) {
          this.open = true;
          this.activeIndex = this.filteredOptions.length - 1;
          this.scrollActiveIntoView();
        } else {
          this.moveActive(-1);
        }
        return;
      case "Enter":
        if (this.open && this.activeIndex >= 0) {
          e.preventDefault();
          const opt = this.filteredOptions[this.activeIndex];
          if (opt) this.commitOption(opt);
        }
        return;
      case "Escape":
        if (this.open) {
          e.preventDefault();
          this.open = false;
        }
        return;
      case "Tab":
        if (this.open) this.open = false;
        return;
    }
  };

  private handleOptionClick = (e: Event) => {
    const el = (e.target as HTMLElement).closest<HTMLElement>(".option");
    if (!el) return;
    const idx = Number(el.dataset.index);
    const opt = this.filteredOptions[idx];
    if (opt) this.commitOption(opt);
  };

  private handleOptionHover = (e: Event) => {
    const el = (e.target as HTMLElement).closest<HTMLElement>(".option");
    if (!el) return;
    this.activeIndex = Number(el.dataset.index);
  };

  private handleOutsideClick = (e: PointerEvent) => {
    if (!this.open) return;
    if (e.composedPath().includes(this)) return;
    this.open = false;
  };

  private get activeId(): string | undefined {
    if (this.activeIndex < 0) return undefined;
    return `${this.listboxId}-opt-${this.activeIndex}`;
  }

  /** Highlight the matched portion of the label. */
  private renderLabel(label: string): TemplateResult {
    const q = this.value.trim();
    if (!q) return html`${label}`;
    const idx = label.toLowerCase().indexOf(q.toLowerCase());
    if (idx < 0) return html`${label}`;
    return html`${label.slice(0, idx)}<span class="match">${label.slice(idx, idx + q.length)}</span
      >${label.slice(idx + q.length)}`;
  }

  private handlePrefixSlotChange = (event: Event): void => {
    const slot = event.target as HTMLSlotElement;
    this.hasPrefix = affixSlotHasContent(slot);
    this.prefixFlush = affixSlotIsFlush(slot);
  };

  private handleSuffixSlotChange = (event: Event): void => {
    const slot = event.target as HTMLSlotElement;
    this.hasSuffix = affixSlotHasContent(slot);
    this.suffixFlush = affixSlotIsFlush(slot);
  };

  override render(): TemplateResult {
    return renderFieldChrome(
      { label: this.label, helpText: this.helpText, for: "input" },
      html`
        <div part="base" class="base">
          <div
            class=${classMap({
              "input-wrap": true,
              [`size-${this.size}`]: true,
              focused: this.focused,
              disabled: this.disabled,
              invalid: this.invalid
            })}
          >
            <span
              class=${classMap({ affix: true, prefix: true, flush: this.prefixFlush })}
              part="prefix"
              ?hidden=${!this.hasPrefix}
            >
              <slot name="prefix" @slotchange=${this.handlePrefixSlotChange}></slot>
            </span>
            <input
              id="input"
              part="input"
              type="text"
              name=${ifDefined(this.name || undefined)}
              role="combobox"
              aria-haspopup="listbox"
              aria-expanded=${this.open ? "true" : "false"}
              aria-controls=${this.listboxId}
              aria-activedescendant=${ifDefined(this.open ? this.activeId : undefined)}
              aria-autocomplete="list"
              aria-label=${ifDefined(this.ariaLabel ?? undefined)}
              aria-describedby=${ifDefined(fieldHelpDescribedBy(this.helpText))}
              aria-invalid=${this.invalid ? "true" : "false"}
              autocomplete="off"
              spellcheck="false"
              .value=${live(this.value)}
              placeholder=${this.placeholder}
              ?disabled=${this.disabled}
              ?required=${this.required}
              @input=${this.handleInput}
              @focus=${this.handleFocus}
              @click=${this.handleClick}
              @blur=${this.handleBlur}
              @keydown=${this.handleKeyDown}
            />
            <span
              class=${classMap({ affix: true, suffix: true, flush: this.suffixFlush })}
              part="suffix"
              ?hidden=${!this.hasSuffix}
            >
              <slot name="suffix" @slotchange=${this.handleSuffixSlotChange}></slot>
            </span>
          </div>
          <div
            part="listbox"
            class="listbox"
            id=${this.listboxId}
            role="listbox"
            popover="manual"
            aria-label=${ifDefined(this.ariaLabel ?? undefined)}
            @click=${this.handleOptionClick}
            @pointermove=${this.handleOptionHover}
          >
            ${this.loading
              ? html`<div class="option-loading">${this.term("loading")}…</div>`
              : this.filteredOptions.length === 0
                ? html`<div class="option-empty">${this.term("noMatches")}</div>`
                : this.filteredOptions.map(
                    (opt, i) => html`
                      <div
                        part="option"
                        class=${classMap({
                          option: true,
                          active: i === this.activeIndex,
                          selected: opt.value === this.selectedValue
                        })}
                        role="option"
                        id=${`${this.listboxId}-opt-${i}`}
                        aria-selected=${i === this.activeIndex ? "true" : "false"}
                        data-index=${i}
                      >
                        ${this.renderOption
                          ? this.renderOption(opt, {
                              index: i,
                              active: i === this.activeIndex,
                              selected: opt.value === this.selectedValue,
                              query: this.value.trim(),
                              highlight: (text: string) => this.renderLabel(text)
                            })
                          : this.renderLabel(opt.label)}
                      </div>
                    `
                  )}
          </div>
          <slot @slotchange=${() => this.requestUpdate()} style="display:none"></slot>
        </div>
      `
    );
  }
}

/** True when a named affix slot actually has something in it. */
function affixSlotHasContent(slot: HTMLSlotElement): boolean {
  return slot.assignedNodes().some((node) => {
    if (node.nodeType === Node.ELEMENT_NODE) return true;
    return node.nodeType === Node.TEXT_NODE && (node.textContent ?? "").trim().length > 0;
  });
}

/** True when a slotted affix opts into edge-to-edge layout via data-flush. */
function affixSlotIsFlush(slot: HTMLSlotElement): boolean {
  return slot.assignedElements().some((el) => el.hasAttribute("data-flush"));
}
