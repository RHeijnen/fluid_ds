import { expect, fixture, html } from "@open-wc/testing";
import "./define.js";
import type { FluidCard } from "./fluid-card.js";

describe("<fluid-card>", () => {
  it("renders with default variant", async () => {
    const el = await fixture<FluidCard>(html`<fluid-card>Body</fluid-card>`);
    expect(el.variant).to.equal("elevated");
  });

  it("renders slot content", async () => {
    const el = await fixture<FluidCard>(html`
      <fluid-card>
        <span slot="header">Title</span>
        <p>Body content</p>
        <span slot="footer">Footer</span>
      </fluid-card>
    `);
    expect(el.textContent).to.include("Title");
    expect(el.textContent).to.include("Body content");
    expect(el.textContent).to.include("Footer");
  });

  it("hides header/footer when empty", async () => {
    const el = await fixture<FluidCard>(html`<fluid-card>Body only</fluid-card>`);
    await el.updateComplete;
    const header = el.shadowRoot!.querySelector(".header")!;
    const footer = el.shadowRoot!.querySelector(".footer")!;
    expect(header.classList.contains("empty")).to.be.true;
    expect(footer.classList.contains("empty")).to.be.true;
  });

  it("reflects variant changes for CSS and external inspection", async () => {
    const el = await fixture<FluidCard>(html`<fluid-card>Body</fluid-card>`);
    el.variant = "outlined";
    await el.updateComplete;
    expect(el.getAttribute("variant")).to.equal("outlined");
  });

  it("updates empty slot state when header and footer content changes", async () => {
    const el = await fixture<FluidCard>(html`<fluid-card>Body</fluid-card>`);
    const header = document.createElement("strong");
    header.slot = "header";
    header.textContent = "Title";
    el.append(header);
    await el.updateComplete;
    await new Promise((resolve) => setTimeout(resolve));
    expect(el.shadowRoot!.querySelector(".header")!.classList.contains("empty")).to.be.false;
    header.remove();
    await new Promise((resolve) => setTimeout(resolve));
    expect(el.shadowRoot!.querySelector(".header")!.classList.contains("empty")).to.be.true;
  });

  it("passes a11y audit", async () => {
    const el = await fixture<FluidCard>(html`
      <fluid-card>
        <h3 slot="header">Card title</h3>
        <p>Content</p>
      </fluid-card>
    `);
    await expect(el).to.be.accessible();
  });
});
