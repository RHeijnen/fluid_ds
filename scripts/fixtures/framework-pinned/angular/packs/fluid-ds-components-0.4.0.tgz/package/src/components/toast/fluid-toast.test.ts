import { expect, fixture, html, oneEvent, aTimeout } from "@open-wc/testing";
import "./define.js";
import "../../locales/nl.js";
import "../../locales/de.js";
import "../../locales/fr.js";
import "../../locales/es.js";
import "../../locales/ar.js";
import type { FluidToast } from "./fluid-toast.js";
import type { FluidToastItem } from "./fluid-toast-item.js";

describe("<fluid-toast> host label ownership", () => {
  type NamedControl = HTMLElement & { updateComplete: Promise<boolean> };
  const mount = () => fixture<HTMLDivElement>('<div lang="en"><fluid-toast></fluid-toast></div>');
  async function settle(control: NamedControl): Promise<void> {
    await new Promise((resolve) => setTimeout(resolve, 0));
    await control.updateComplete;
  }

  for (const [locale, expected] of [
    ["nl", "Meldingen"],
    ["de", "Benachrichtigungen"],
    ["fr", "Notifications"],
    ["es", "Notificaciones"],
    ["ar", "الإشعارات"],
    ["fr-CA", "Notifications"]
  ] as const) {
    it(`updates the owned host name for ${locale} and after reconnect`, async () => {
      const wrapper = await mount();
      const control = wrapper.firstElementChild as NamedControl;
      expect(control.getAttribute("aria-label")).to.equal("Notifications");
      wrapper.lang = locale;
      await settle(control);
      expect(control.getAttribute("aria-label")).to.equal(expected);
      control.remove();
      wrapper.lang = "nl";
      wrapper.append(control);
      await settle(control);
      expect(control.getAttribute("aria-label")).to.equal("Meldingen");
    });
  }

  for (const explicit of ["", "Notifications", "Application name"]) {
    it(`preserves initially authored ${JSON.stringify(explicit)} through locale changes and reconnect`, async () => {
      const control = document.createElement("fluid-toast") as NamedControl;
      control.setAttribute("aria-label", explicit);
      const wrapper = await fixture<HTMLDivElement>('<div lang="nl"></div>');
      wrapper.append(control);
      await settle(control);
      expect(control.getAttribute("aria-label")).to.equal(explicit);
      wrapper.lang = "fr";
      await settle(control);
      expect(control.getAttribute("aria-label")).to.equal(explicit);
      control.remove();
      wrapper.append(control);
      await settle(control);
      expect(control.getAttribute("aria-label")).to.equal(explicit);
      control.removeAttribute("aria-label");
      await settle(control);
      expect(control.getAttribute("aria-label")).to.equal("Notifications");
    });
  }

  it("recognizes late same-value writes as application ownership and restores removed overrides immediately", async () => {
    const wrapper = await mount();
    const control = wrapper.firstElementChild as NamedControl;
    for (const explicit of ["Notifications", "", "Application name"]) {
      control.setAttribute("aria-label", explicit);
      wrapper.lang = wrapper.lang === "fr" ? "nl" : "fr";
      await settle(control);
      expect(control.getAttribute("aria-label")).to.equal(explicit);
    }
    control.removeAttribute("aria-label");
    await settle(control);
    expect(control.getAttribute("aria-label")).to.equal(
      wrapper.lang === "fr" ? "Notifications" : "Meldingen"
    );
  });

  it("preserves native ariaLabel property writes, including equal defaults, empty strings and null reset", async () => {
    const wrapper = await mount();
    const control = wrapper.firstElementChild as NamedControl;
    for (const explicit of ["Notifications", "", "Property name"]) {
      control.ariaLabel = explicit;
      wrapper.lang = wrapper.lang === "fr" ? "nl" : "fr";
      await settle(control);
      expect(control.ariaLabel).to.equal(explicit);
      expect(control.getAttribute("aria-label")).to.equal(explicit);
    }
    control.ariaLabel = null;
    await settle(control);
    expect(control.getAttribute("aria-label")).to.equal(
      wrapper.lang === "fr" ? "Notifications" : "Meldingen"
    );
  });

  it("withdraws only its owned fallback while aria-labelledby exists and restores it on removal", async () => {
    const wrapper = await mount();
    const control = wrapper.firstElementChild as NamedControl;
    const label = document.createElement("span");
    label.id = "application-toast-label";
    label.textContent = "Application heading";
    wrapper.append(label);
    control.setAttribute("aria-labelledby", label.id);
    await settle(control);
    expect(control.hasAttribute("aria-label")).to.equal(false);
    wrapper.lang = "fr";
    await settle(control);
    expect(control.getAttribute("aria-labelledby")).to.equal(label.id);
    expect(control.hasAttribute("aria-label")).to.equal(false);
    control.removeAttribute("aria-labelledby");
    await settle(control);
    expect(control.getAttribute("aria-label")).to.equal("Notifications");
  });

  it("never removes an authored aria-label when aria-labelledby is added or removed", async () => {
    const wrapper = await mount();
    const control = wrapper.firstElementChild as NamedControl;
    control.setAttribute("aria-label", "Author fallback");
    control.setAttribute("aria-labelledby", "application-external-label");
    wrapper.lang = "fr";
    await settle(control);
    expect(control.getAttribute("aria-label")).to.equal("Author fallback");
    control.removeAttribute("aria-labelledby");
    await settle(control);
    expect(control.getAttribute("aria-label")).to.equal("Author fallback");
  });

  it("retains ownership after detached edits and follows a closed-shadow locale context", async () => {
    const wrapper = await fixture<HTMLDivElement>('<div lang="en"></div>');
    const context = document.createElement("div");
    const root = context.attachShadow({ mode: "closed" });
    const control = document.createElement("fluid-toast") as NamedControl;
    root.append(control);
    wrapper.append(context);
    await settle(control);
    context.lang = "fr-CA";
    await settle(control);
    expect(control.getAttribute("aria-label")).to.equal("Notifications");
    control.remove();
    control.setAttribute("aria-label", "Notifications");
    context.lang = "nl";
    root.append(control);
    await settle(control);
    expect(control.getAttribute("aria-label")).to.equal("Notifications");
    control.remove();
    control.removeAttribute("aria-label");
    root.append(control);
    await settle(control);
    expect(control.getAttribute("aria-label")).to.equal("Meldingen");
  });
});

describe("<fluid-toast>", () => {
  it("updates only the region name without replacing toast items, content or focus", async () => {
    const el = await fixture<FluidToast>(html`<fluid-toast lang="en"></fluid-toast>`);
    const message = document.createElement("button");
    message.textContent = "Application action";
    const item = el.toast({ message, duration: 0 });
    await item.updateComplete;
    message.focus();
    el.lang = "nl";
    await aTimeout(0);
    await el.updateComplete;
    expect(el.getAttribute("aria-label")).to.equal("Meldingen");
    expect(el.firstElementChild === item).to.equal(true);
    expect(item.contains(message)).to.equal(true);
    expect(message.textContent).to.equal("Application action");
    expect(document.activeElement === message).to.equal(true);
    item.dismiss();
    await aTimeout(250);
    expect(el.querySelector("fluid-toast-item")).to.equal(null);
  });

  it("passes a11y audits when empty and with a live toast", async () => {
    const el = await fixture<FluidToast>(
      html`<fluid-toast aria-label="Notifications"></fluid-toast>`
    );
    await expect(el).to.be.accessible();
    el.toast({ message: "Profile saved", duration: 0 });
    await el.updateComplete;
    await expect(el).to.be.accessible();
  });

  it("renders as a region", async () => {
    const el = await fixture<FluidToast>(html`<fluid-toast></fluid-toast>`);
    expect(el.getAttribute("role")).to.equal("region");
  });

  it("toast() appends an item", async () => {
    const el = await fixture<FluidToast>(html`<fluid-toast></fluid-toast>`);
    el.toast({ message: "Hi", duration: 0 });
    expect(el.querySelectorAll("fluid-toast-item").length).to.equal(1);
  });

  it("auto-dismisses after duration", async () => {
    const el = await fixture<FluidToast>(html`<fluid-toast></fluid-toast>`);
    const item = el.toast({ message: "bye", duration: 10 });
    await oneEvent(item, "fluid-dismiss");
    await aTimeout(10);
    expect(el.querySelectorAll("fluid-toast-item").length).to.equal(0);
  });

  it("sticky toasts don't auto-dismiss", async () => {
    const el = await fixture<FluidToast>(html`<fluid-toast></fluid-toast>`);
    el.toast({ message: "sticky", duration: 0 });
    await aTimeout(60);
    expect(el.querySelectorAll("fluid-toast-item").length).to.equal(1);
  });

  it("clear() dismisses all toasts", async () => {
    const el = await fixture<FluidToast>(html`<fluid-toast></fluid-toast>`);
    el.toast({ message: "a", duration: 0 });
    el.toast({ message: "b", duration: 0 });
    el.clear();
    await aTimeout(250);
    expect(el.querySelectorAll("fluid-toast-item").length).to.equal(0);
  });
});

describe("<fluid-toast-item>", () => {
  it("uses role=alert for danger variant", async () => {
    const el = await fixture<FluidToastItem>(html`
      <fluid-toast-item variant="danger" .duration=${0}>Oops</fluid-toast-item>
    `);
    expect(el.getAttribute("role")).to.equal("alert");
  });

  it("uses role=status for other variants", async () => {
    const el = await fixture<FluidToastItem>(html`
      <fluid-toast-item .duration=${0}>Info</fluid-toast-item>
    `);
    expect(el.getAttribute("role")).to.equal("status");
  });

  /* Rework: override ladder + AAA target floor. */

  it("background reads the --fluid-toast-item-* override ladder", async () => {
    const el = await fixture<FluidToastItem>(html`
      <fluid-toast-item .duration=${0}>x</fluid-toast-item>
    `);
    el.style.setProperty("--fluid-toast-item-bg", "rgb(1, 2, 3)");
    await el.updateComplete;
    const base = el.shadowRoot!.querySelector<HTMLElement>(".base")!;
    expect(getComputedStyle(base).backgroundColor).to.equal("rgb(1, 2, 3)");
  });

  it("the close button respects --fluid-target-min (AAA hit area)", async () => {
    const el = await fixture<FluidToastItem>(html`
      <fluid-toast-item .duration=${0}>x</fluid-toast-item>
    `);
    el.style.setProperty("--fluid-target-min", "44px");
    await el.updateComplete;
    const close = el.shadowRoot!.querySelector<HTMLElement>(".close")!;
    expect(close.getBoundingClientRect().height).to.be.greaterThanOrEqual(44);
  });
});
