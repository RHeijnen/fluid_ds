import { expect, fixture, html, oneEvent } from "@open-wc/testing";
import "./define.js";
import type { FluidDialog } from "./fluid-dialog.js";

describe("<fluid-dialog>", () => {
  it("passes a11y audits while closed and open", async () => {
    const el = await fixture<FluidDialog>(html`
      <fluid-dialog aria-label="Account settings"><p>Dialog body</p></fluid-dialog>
    `);
    expect(el.hasAttribute("aria-label")).to.equal(false);
    expect(el.shadowRoot!.querySelector("dialog")!.getAttribute("aria-label")).to.equal(
      "Account settings"
    );
    await expect(el).to.be.accessible();
    el.show();
    await el.updateComplete;
    await expect(el).to.be.accessible();
    el.hide();
  });

  it("renders closed by default", async () => {
    const el = await fixture<FluidDialog>(html` <fluid-dialog aria-label="x">Body</fluid-dialog> `);
    expect(el.open).to.be.false;
    expect(el.shadowRoot!.querySelector("dialog")!.open).to.be.false;
  });

  it("opens via show()", async () => {
    const el = await fixture<FluidDialog>(html` <fluid-dialog aria-label="x">Body</fluid-dialog> `);
    setTimeout(() => el.show());
    const event = await oneEvent(el, "fluid-show");
    expect(event.detail).to.equal(null);
    expect([event.bubbles, event.composed, event.cancelable]).to.deep.equal([true, true, false]);
    expect(el.open).to.be.true;
  });

  it("fires fluid-hide when closed", async () => {
    const el = await fixture<FluidDialog>(html`
      <fluid-dialog aria-label="x" open>Body</fluid-dialog>
    `);
    await el.updateComplete;
    setTimeout(() => el.hide());
    const event = await oneEvent(el, "fluid-hide");
    expect(event.detail).to.equal(null);
    expect([event.bubbles, event.composed, event.cancelable]).to.deep.equal([true, true, false]);
    expect(el.open).to.be.false;
  });

  it("restores modality after reconnect without duplicate lifecycle events", async () => {
    const el = await fixture<FluidDialog>(html` <fluid-dialog aria-label="x">Body</fluid-dialog> `);
    const events: string[] = [];
    el.addEventListener("fluid-show", () => events.push("show"));
    el.addEventListener("fluid-hide", () => events.push("hide"));
    el.show();
    await el.updateComplete;

    const parent = el.parentElement!;
    el.remove();
    parent.append(el);
    await el.updateComplete;
    await new Promise<void>((resolve) => requestAnimationFrame(() => resolve()));

    const dialog = el.shadowRoot!.querySelector("dialog")!;
    expect(el.open).to.equal(true);
    expect(dialog.open).to.equal(true);
    expect(dialog.matches(":modal")).to.equal(true);
    expect(el.shadowRoot!.activeElement?.classList.contains("close")).to.equal(true);
    expect(events).to.deep.equal(["show"]);

    const hideEvent = oneEvent(el, "fluid-hide");
    el.hide();
    await el.updateComplete;
    await hideEvent;
    expect(events).to.deep.equal(["show", "hide"]);
  });

  it("renders the close button by default", async () => {
    const el = await fixture<FluidDialog>(html` <fluid-dialog aria-label="x">Body</fluid-dialog> `);
    expect(el.shadowRoot!.querySelector(".close")).to.exist;
  });

  it("keeps the internal close glyph decorative and closes through the translated button", async () => {
    const el = await fixture<FluidDialog>(
      html`<fluid-dialog aria-label="Settings" open>Body</fluid-dialog>`
    );
    await el.updateComplete;
    const close = el.shadowRoot!.querySelector<HTMLButtonElement>(".close")!;
    const glyph = close.querySelector("svg")!;
    expect(close.getAttribute("aria-label")).to.equal("Close dialog");
    expect(glyph.getAttribute("aria-hidden")).to.equal("true");
    setTimeout(() => close.click());
    await oneEvent(el, "fluid-hide");
    expect(el.open).to.equal(false);
  });

  it("omits the close button when no-close-button is set", async () => {
    const el = await fixture<FluidDialog>(html`
      <fluid-dialog aria-label="x" no-close-button>Body</fluid-dialog>
    `);
    expect(el.shadowRoot!.querySelector(".close")).to.be.null;
  });

  /* Rework: override ladder + AAA target floor. */

  it("panel background reads the --fluid-dialog-* override ladder", async () => {
    const el = await fixture<FluidDialog>(html`
      <fluid-dialog aria-label="x" open>Body</fluid-dialog>
    `);
    el.style.setProperty("--fluid-dialog-bg", "rgb(1, 2, 3)");
    await el.updateComplete;
    const panel = el.shadowRoot!.querySelector<HTMLElement>(".panel")!;
    expect(getComputedStyle(panel).backgroundColor).to.equal("rgb(1, 2, 3)");
  });

  it("the close button respects --fluid-target-min (AAA hit area)", async () => {
    const el = await fixture<FluidDialog>(html`
      <fluid-dialog aria-label="x" open>Body</fluid-dialog>
    `);
    el.style.setProperty("--fluid-target-min", "44px");
    await el.updateComplete;
    const close = el.shadowRoot!.querySelector<HTMLElement>(".close")!;
    expect(close.getBoundingClientRect().height).to.be.greaterThanOrEqual(44);
  });

  it("renders slot=heading content in the title row as a label alias", async () => {
    const el = await fixture<FluidDialog>(html`
      <fluid-dialog open
        ><h2 slot="heading">Settings</h2>
        <p>Body</p></fluid-dialog
      >
    `);
    const labelSlot = el.shadowRoot!.querySelector<HTMLSlotElement>('slot[name="label"]')!;
    const flattened = labelSlot.assignedNodes({ flatten: true });
    const hasHeading = flattened.some(
      (n) => n instanceof HTMLElement && n.textContent === "Settings"
    );
    expect(hasHeading).to.equal(true);
    const dialog = el.shadowRoot!.querySelector("dialog")!;
    expect(dialog.getAttribute("aria-labelledby")).to.equal("fluid-dialog-label");
    expect(dialog.hasAttribute("aria-label")).to.equal(false);
  });
});
