import { expect, fixture, html, aTimeout } from "@open-wc/testing";
import "./define.js";
import type { FluidPopup } from "./fluid-popup.js";

describe("<fluid-popup>", () => {
  it("passes an a11y audit with an authored trigger and named content", async () => {
    const el = await fixture<FluidPopup>(html`
      <fluid-popup open>
        <button slot="anchor" aria-expanded="true">Show details</button>
        <section aria-label="Details">Popup content</section>
      </fluid-popup>
    `);
    await expect(el).to.be.accessible();
  });

  it("renders an anchor slot and a popup slot", async () => {
    const el = await fixture<FluidPopup>(html`
      <fluid-popup>
        <button slot="anchor">Trigger</button>
        <div>Content</div>
      </fluid-popup>
    `);
    expect(el.shadowRoot!.querySelectorAll("slot").length).to.equal(2);
  });

  it("hides the popup when not open", async () => {
    const el = await fixture<FluidPopup>(html`
      <fluid-popup>
        <button slot="anchor">a</button>
        <div>c</div>
      </fluid-popup>
    `);
    await el.updateComplete;
    const popup = el.shadowRoot!.querySelector<HTMLElement>(".popup")!;
    expect(getComputedStyle(popup).display).to.equal("none");
  });

  it("positions the popup when open", async () => {
    const el = await fixture<FluidPopup>(html`
      <fluid-popup open>
        <button slot="anchor" style="position: absolute; left: 100px; top: 100px;">a</button>
        <div style="width: 50px; height: 50px;">c</div>
      </fluid-popup>
    `);
    await el.updateComplete;
    await aTimeout(50);
    const popup = el.shadowRoot!.querySelector<HTMLElement>(".popup")!;
    expect(popup.style.left).to.not.equal("0px");
  });

  it("matches the anchor width when match-width is set", async () => {
    const el = await fixture<FluidPopup>(html`
      <fluid-popup open match-width>
        <button slot="anchor" style="width: 200px;">a</button>
        <div>c</div>
      </fluid-popup>
    `);
    await el.updateComplete;
    await aTimeout(50);
    const popup = el.shadowRoot!.querySelector<HTMLElement>(".popup")!;
    expect(popup.style.width).to.match(/2\d\dpx/);
  });

  it("repositions when the inherited writing direction changes", async () => {
    const wrapper = await fixture<HTMLElement>(html`
      <div dir="ltr">
        <fluid-popup open .flip=${false} .shift=${false}>
          <button slot="anchor" style="position: absolute; left: 100px; top: 100px;">a</button>
          <div style="width: 50px; height: 50px;">c</div>
        </fluid-popup>
      </div>
    `);
    const el = wrapper.querySelector<FluidPopup>("fluid-popup")!;
    await el.updateComplete;
    await aTimeout(50);
    let repositionCount = 0;
    el.addEventListener("fluid-reposition", () => (repositionCount += 1));

    wrapper.dir = "rtl";
    await aTimeout(0);
    await el.updateComplete;
    await aTimeout(50);

    expect(repositionCount).to.be.greaterThan(0);
  });
});
