import { expect, fixture, html, oneEvent } from "@open-wc/testing";
import "./define.js";
import type { FluidDrawer } from "./fluid-drawer.js";

describe("<fluid-drawer>", () => {
  it("passes a11y audits while closed and open", async () => {
    const el = await fixture<FluidDrawer>(html`
      <fluid-drawer aria-label="Filters"><p>Drawer body</p></fluid-drawer>
    `);
    expect(el.hasAttribute("aria-label")).to.equal(false);
    expect(el.shadowRoot!.querySelector("dialog")!.getAttribute("aria-label")).to.equal("Filters");
    await expect(el).to.be.accessible();
    el.show();
    await el.updateComplete;
    await expect(el).to.be.accessible();
    el.hide();
  });

  it("renders closed by default", async () => {
    const el = await fixture<FluidDrawer>(html` <fluid-drawer aria-label="x">Body</fluid-drawer> `);
    expect(el.open).to.be.false;
  });

  it("opens via show()", async () => {
    const el = await fixture<FluidDrawer>(html` <fluid-drawer aria-label="x">Body</fluid-drawer> `);
    setTimeout(() => el.show());
    const event = await oneEvent(el, "fluid-show");
    expect(event.detail).to.equal(null);
    expect([event.bubbles, event.composed, event.cancelable]).to.deep.equal([true, true, false]);
    expect(el.open).to.be.true;
  });

  it("supports placement attribute", async () => {
    const el = await fixture<FluidDrawer>(html`
      <fluid-drawer aria-label="x" placement="start">Body</fluid-drawer>
    `);
    expect(el.placement).to.equal("start");
  });

  it("fires fluid-hide on close", async () => {
    const el = await fixture<FluidDrawer>(html`
      <fluid-drawer aria-label="x" open>Body</fluid-drawer>
    `);
    await el.updateComplete;
    setTimeout(() => el.hide());
    const event = await oneEvent(el, "fluid-hide");
    expect(event.detail).to.equal(null);
    expect([event.bubbles, event.composed, event.cancelable]).to.deep.equal([true, true, false]);
  });

  /* Rework: override ladder + AAA target floor. */

  it("panel background reads the --fluid-drawer-* override ladder", async () => {
    const el = await fixture<FluidDrawer>(html`
      <fluid-drawer aria-label="x" open>Body</fluid-drawer>
    `);
    el.style.setProperty("--fluid-drawer-bg", "rgb(1, 2, 3)");
    await el.updateComplete;
    const panel = el.shadowRoot!.querySelector<HTMLElement>(".panel")!;
    expect(getComputedStyle(panel).backgroundColor).to.equal("rgb(1, 2, 3)");
  });

  it("the close button respects --fluid-target-min (AAA hit area)", async () => {
    const el = await fixture<FluidDrawer>(html`
      <fluid-drawer aria-label="x" open>Body</fluid-drawer>
    `);
    el.style.setProperty("--fluid-target-min", "44px");
    await el.updateComplete;
    const close = el.shadowRoot!.querySelector<HTMLElement>(".close")!;
    expect(close.getBoundingClientRect().height).to.be.greaterThanOrEqual(44);
  });

  it("uses slotted label content as the native dialog accessible name", async () => {
    const el = await fixture<FluidDrawer>(html`
      <fluid-drawer open
        ><h2 slot="label">Filters</h2>
        <p>Body</p></fluid-drawer
      >
    `);
    const dialog = el.shadowRoot!.querySelector("dialog")!;
    expect(dialog.getAttribute("aria-labelledby")).to.equal("fluid-drawer-label");
    expect(dialog.hasAttribute("aria-label")).to.equal(false);
  });
});
