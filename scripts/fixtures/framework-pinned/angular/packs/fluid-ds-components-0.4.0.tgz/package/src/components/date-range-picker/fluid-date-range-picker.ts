import { html, css, type PropertyValues, type TemplateResult } from "lit";
import { property, state, query } from "lit/decorators.js";
import { live } from "lit/directives/live.js";
import { autoUpdate, computePosition, flip, offset, shift } from "../../internal/position.js";
import { FluidFormAssociated } from "../../internal/form-associated.js";
import { reducedMotion } from "../../internal/motion.js";
import "../calendar/define.js";
import {
  type Weekday,
  type RangePreset,
  defaultRangePresets,
  matchPreset,
  fromISODate,
  toISODate,
  formatDate,
  compareDay,
  addMonths
} from "../../internal/date-utils.js";

type DisplayFormat = "short" | "medium" | "long" | "numeric" | "iso";

function fmtOpts(format: DisplayFormat): Intl.DateTimeFormatOptions | null {
  switch (format) {
    case "iso":
      return null;
    case "numeric":
      return { year: "numeric", month: "2-digit", day: "2-digit" };
    case "short":
      return { dateStyle: "short" };
    case "long":
      return { dateStyle: "long" };
    default:
      return { dateStyle: "medium" };
  }
}

let counter = 0;

/**
 * A date-range picker: a form-associated field that opens a popover with a
 * preset column, two month grids (fluid-calendar), and Apply / Cancel.
 *
 * `start` and `end` are ISO `YYYY-MM-DD` (timezone-safe). The form value is the
 * ISO interval `start/end`. `fluid-change` carries
 * `{ start, end, startDate, endDate }`. Presets default to a sensible list,
 * are fully customizable via `.presets`, and can be turned off with `no-presets`.
 *
 * Accessibility: WAI-ARIA APG Date Picker Dialog over two grids. Each grid is a
 * full keyboard `role="grid"` (see fluid-calendar). Esc closes and restores
 * focus; the preset column is a labeled list of buttons.
 *
 * @summary Pick a start + end date.
 *
 * @csspart base - The field container.
 * @csspart input - The text input.
 * @csspart trigger - The calendar toggle button.
 * @csspart dialog - The popover.
 * @csspart presets - The preset column.
 * @csspart calendars - The two-month grid wrapper.
 * @csspart footer - The selected-range + actions row.
 *
 * @cssproperty --fluid-date-range-picker-bg - Field background. Falls back to --fluid-input-bg → --fluid-surface-base.
 * @cssproperty --fluid-date-range-picker-border - Field border. Falls back to --fluid-input-border → --fluid-border-default.
 * @cssproperty --fluid-date-range-picker-dialog-bg - Popover background. Falls back to --fluid-surface-base.
 * @cssproperty --fluid-date-range-picker-dialog-shadow - Popover elevation. Falls back to --fluid-shadow-lg.
 * @cssproperty --fluid-date-range-picker-preset-active-bg - Active preset fill. Falls back to a 15% accent tint.
 * @cssproperty --fluid-date-range-picker-radius - Field radius. Falls back to --fluid-field-border-radius → --fluid-radius-md.
 *
 * @uses-token --fluid-surface-base - Field + dialog background.
 * @uses-token --fluid-surface-muted - Preset hover.
 * @uses-token --fluid-text-primary - Field text.
 * @uses-token --fluid-border-default - Borders.
 * @uses-token --fluid-accent-base - Focus + active preset.
 * @uses-token --fluid-font-size-sm - Text size at size="sm".
 * @uses-token --fluid-font-size-md - Text size at size="md".
 * @uses-token --fluid-font-size-lg - Text size at size="lg".
 * @uses-token --fluid-field-border-radius - Field radius.
 * @uses-token --fluid-field-height-md - Field height.
 * @uses-token --fluid-focus-ring-width - Focus ring width.
 * @uses-token --fluid-target-min - Min target size.
 *
 * @fires fluid-change - The range was applied, by calendar or by typing when
 *   `typeable` is set. `detail: { start, end, startDate, endDate }`.
 * @fires fluid-open - The popover opened.
 * @fires fluid-close - The popover closed.
 * @cssproperty --fluid-date-range-picker-accent-base - Component override for the corresponding semantic token.
 * @cssproperty --fluid-date-range-picker-accent-text - Component override for the corresponding semantic token.
 * @cssproperty --fluid-date-range-picker-border-default - Component override for the corresponding semantic token.
 * @cssproperty --fluid-date-range-picker-surface-base - Component override for the corresponding semantic token.
 * @cssproperty --fluid-date-range-picker-surface-muted - Component override for the corresponding semantic token.
 * @cssproperty --fluid-date-range-picker-text-primary - Component override for the corresponding semantic token.
 * @cssproperty --fluid-date-range-picker-text-secondary - Component override for the corresponding semantic token.
 */
export class FluidDateRangePicker extends FluidFormAssociated {
  static override shadowRootOptions: ShadowRootInit = {
    ...FluidFormAssociated.shadowRootOptions,
    delegatesFocus: true
  };

  static override formAssociated = true;

  static override styles = [
    reducedMotion,
    css`
      :host {
        display: inline-block;
        font-family: var(--fluid-font-family-sans);
      }
      :host([disabled]) {
        opacity: 0.6;
        pointer-events: none;
      }
      .base {
        display: inline-flex;
        align-items: center;
        gap: 0.25rem;
        min-width: 16rem;
        height: var(--fluid-field-height-md, 2.5rem);
        padding-inline: var(--fluid-field-padding-x-md, 0.75rem);
        background: var(
          --fluid-date-range-picker-bg,
          var(--fluid-input-bg, var(--fluid-surface-base))
        );
        color: var(
          --fluid-input-fg,
          var(--fluid-date-range-picker-text-primary, var(--fluid-text-primary))
        );
        border: var(--fluid-field-border-width, 1px) solid
          var(
            --fluid-date-range-picker-border,
            var(--fluid-input-border, var(--fluid-border-default))
          );
        border-radius: var(
          --fluid-date-range-picker-radius,
          var(--fluid-field-border-radius, var(--fluid-radius-md))
        );
        transition:
          border-color 120ms ease,
          box-shadow 120ms ease;
      }
      /* Font scales with the size, as it does on every other field. Sized
         by height alone, a sm picker kept the md text: beside a sm input and
         a sm select on the same toolbar row it was the one control reading a
         size larger, and consumers had no size-aware token to correct it. */
      .base {
        font-size: var(--fluid-font-size-md);
      }
      :host([size="sm"]) .base {
        height: var(--fluid-field-height-sm, 2rem);
        font-size: var(--fluid-font-size-sm);
      }
      :host([size="lg"]) .base {
        height: var(--fluid-field-height-lg, 3rem);
        font-size: var(--fluid-font-size-lg);
      }
      .base:focus-within {
        border-color: var(--fluid-date-range-picker-accent-base, var(--fluid-accent-base));
        outline: var(--fluid-focus-ring-width, 2px) solid
          color-mix(
            in srgb,
            var(--fluid-date-range-picker-accent-base, var(--fluid-accent-base)) 35%,
            transparent
          );
      }
      input {
        flex: 1;
        min-width: 10rem;
        border: 0;
        outline: none;
        background: transparent;
        color: inherit;
        font: inherit;
        padding: 0;
      }
      input::placeholder {
        color: var(
          --fluid-input-placeholder-fg,
          var(--fluid-date-range-picker-text-secondary, var(--fluid-text-secondary))
        );
      }
      .trigger {
        display: inline-grid;
        place-items: center;
        min-width: max(1.5rem, var(--fluid-target-min, 0px));
        min-height: max(1.5rem, var(--fluid-target-min, 0px));
        margin-inline-end: -0.25rem;
        border: 0;
        border-radius: var(--fluid-radius-sm, 4px);
        background: transparent;
        color: var(--fluid-date-range-picker-text-secondary, var(--fluid-text-secondary));
        cursor: pointer;
      }
      .trigger:hover {
        color: var(--fluid-date-range-picker-text-primary, var(--fluid-text-primary));
      }
      .trigger:focus-visible {
        outline: var(--fluid-focus-ring-width, 2px) solid
          var(--fluid-date-range-picker-accent-base, var(--fluid-accent-base));
        outline-offset: 1px;
      }
      svg {
        width: 1.1em;
        height: 1.1em;
      }

      /* Rendered in the top layer via popover="manual" so it is never clipped
         by an ancestor's overflow / transform / contain (a plain position:fixed
         can still be trapped by a transformed containing block). The positioning engine
         left/top still drive placement. */
      .dialog {
        position: fixed;
        inset: auto;
        top: 0;
        left: 0;
        z-index: 1000;
        margin: 0;
        background: var(--fluid-date-range-picker-dialog-bg, var(--fluid-surface-base));
        border: 1px solid var(--fluid-date-range-picker-border-default, var(--fluid-border-default));
        border-radius: var(--fluid-radius-lg, 0.75rem);
        box-shadow: var(
          --fluid-date-range-picker-dialog-shadow,
          var(--fluid-shadow-lg, 0 12px 32px -8px rgba(0, 0, 0, 0.25))
        );
        opacity: 0;
        transform: scale(0.97);
        transform-origin: top left;
        transition:
          opacity calc(var(--fluid-duration-fast, 120ms) * var(--fluid-motion, 1)) ease,
          transform calc(var(--fluid-duration-fast, 120ms) * var(--fluid-motion, 1)) ease,
          overlay calc(var(--fluid-duration-fast, 120ms) * var(--fluid-motion, 1)) allow-discrete,
          display calc(var(--fluid-duration-fast, 120ms) * var(--fluid-motion, 1)) allow-discrete;
      }
      .dialog:popover-open {
        display: flex;
        opacity: 1;
        transform: scale(1);
      }
      @starting-style {
        .dialog:popover-open {
          opacity: 0;
          transform: scale(0.97);
        }
      }
      .presets {
        display: flex;
        flex-direction: column;
        gap: 0.15rem;
        padding: 0.65rem;
        min-width: 9rem;
        border-inline-end: 1px solid
          var(--fluid-date-range-picker-border-default, var(--fluid-border-default));
      }
      .preset {
        text-align: left;
        padding: 0.4rem 0.6rem;
        border: 0;
        border-radius: var(--fluid-radius-md, 6px);
        background: transparent;
        color: inherit;
        font: inherit;
        cursor: pointer;
        min-height: max(1.75rem, var(--fluid-target-min, 0px));
      }
      .preset:hover {
        background: var(--fluid-date-range-picker-surface-muted, var(--fluid-surface-muted));
      }
      .preset[aria-pressed="true"] {
        background: var(
          --fluid-date-range-picker-preset-active-bg,
          color-mix(in srgb, var(--fluid-accent-base) 15%, transparent)
        );
        color: var(--fluid-date-range-picker-accent-base, var(--fluid-accent-base));
        font-weight: 600;
      }
      .preset:focus-visible {
        outline: var(--fluid-focus-ring-width, 2px) solid
          var(--fluid-date-range-picker-accent-base, var(--fluid-accent-base));
        outline-offset: 1px;
      }
      .right {
        display: flex;
        flex-direction: column;
      }
      .cal-head {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 0.65rem 0.65rem 0;
      }
      .nav-button {
        display: inline-grid;
        place-items: center;
        min-width: max(1.75rem, var(--fluid-target-min, 0px));
        min-height: max(1.75rem, var(--fluid-target-min, 0px));
        border: 0;
        border-radius: var(--fluid-radius-md, 6px);
        background: transparent;
        color: inherit;
        font: inherit;
        cursor: pointer;
      }
      .nav-button:hover {
        background: var(--fluid-date-range-picker-surface-muted, var(--fluid-surface-muted));
      }
      .nav-button:focus-visible {
        outline: var(--fluid-focus-ring-width, 2px) solid
          var(--fluid-date-range-picker-accent-base, var(--fluid-accent-base));
        outline-offset: 1px;
      }
      .calendars {
        display: flex;
        gap: 0.5rem;
        padding: 0.5rem 0.65rem;
      }
      .calendars fluid-calendar + fluid-calendar {
        border-inline-start: 1px solid
          var(--fluid-date-range-picker-border-default, var(--fluid-border-default));
        padding-inline-start: 0.5rem;
      }
      .footer {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 1rem;
        padding: 0.65rem;
        border-top: 1px solid
          var(--fluid-date-range-picker-border-default, var(--fluid-border-default));
      }
      .selected-range {
        font-size: 0.875rem;
        color: var(--fluid-date-range-picker-text-secondary, var(--fluid-text-secondary));
      }
      .actions {
        display: flex;
        gap: 0.5rem;
      }
      .btn {
        padding: 0.4rem 0.85rem;
        border-radius: var(--fluid-radius-md, 6px);
        font: inherit;
        cursor: pointer;
        min-height: max(2rem, var(--fluid-target-min, 0px));
        border: 1px solid var(--fluid-date-range-picker-border-default, var(--fluid-border-default));
        background: var(--fluid-date-range-picker-surface-base, var(--fluid-surface-base));
        color: inherit;
      }
      .btn.apply {
        background: var(--fluid-date-range-picker-accent-base, var(--fluid-accent-base));
        color: var(--fluid-date-range-picker-accent-text, var(--fluid-accent-text));
        border-color: transparent;
      }
      .btn:disabled {
        opacity: 0.5;
        cursor: not-allowed;
      }
      .btn:focus-visible {
        outline: var(--fluid-focus-ring-width, 2px) solid
          var(--fluid-date-range-picker-accent-base, var(--fluid-accent-base));
        outline-offset: 2px;
      }
      @media (max-width: 560px) {
        .calendars fluid-calendar + fluid-calendar {
          display: none;
        }
      }
    `
  ];

  /** Range start, ISO `YYYY-MM-DD`. */
  @property() start: string | null = null;
  /** Range end, ISO `YYYY-MM-DD`. */
  @property() end: string | null = null;

  @property() override name = "";
  @property({ type: Boolean, reflect: true }) disabled = false;
  @property({ type: Boolean }) required = false;
  @property({ type: Boolean }) readonly = false;
  @property()
  get placeholder(): string {
    return this.placeholderOverride ?? this.term("selectDateRange");
  }
  set placeholder(value: string | null) {
    this.placeholderOverride = value;
  }
  private placeholderOverride: string | null = null;

  @property() min: string | null = null;
  @property() max: string | null = null;
  @property({ type: Number, attribute: "week-start" }) weekStart: Weekday = 1;
  @property() locale: string | undefined = undefined;
  @property() format: DisplayFormat = "medium";
  @property({ reflect: true }) size: "sm" | "md" | "lg" = "md";

  /** Hide the preset column. */
  @property({ type: Boolean, attribute: "no-presets" }) noPresets = false;
  /**
   * Let the range be typed as well as picked. Off by default: the field is
   * read-only and the calendar is the only way in, which is what most callers
   * want. Turned on, the text is parsed on Enter or blur and applied like a
   * calendar selection; anything unparseable reverts to the committed range.
   */
  @property({ type: Boolean, reflect: true }) typeable = false;
  /**
   * Fixed day/month/year pattern for the text side of the field, e.g.
   * `DD-MM-YY`. Governs display *and* typed parsing together, so what the
   * field shows is always something it will accept back.
   *
   * Unset, the field formats via `format` + `locale` and reads typed text as
   * ISO or whatever the platform parser makes of it. Set it when the text has
   * to match an existing control exactly — a locale-formatted `8/9/26` and a
   * `DD-MM-YY` `09-08-26` are both valid-looking and mean different days.
   *
   * Tokens: `DD`/`D` day, `MM`/`M` month, `YYYY`/`YY` year. Anything else is
   * a literal.
   */
  @property({ attribute: "date-pattern" }) datePattern: string | null = null;

  /** Preset list (property only; defaults to the built-in set). */
  @property({ attribute: false }) presets: RangePreset[] = defaultRangePresets;

  @property({ type: Boolean, reflect: true }) open = false;

  /** Form value: the ISO interval `start/end`, derived from `start` + `end`. */
  @property() override value: string | null = null;

  @state() private tempStart: string | null = null;
  @state() private tempEnd: string | null = null;
  @state() private hover: string | null = null;
  @state() private viewISO: string | null = null;
  @state() private typed = "";

  @query("input") private inputEl!: HTMLInputElement;
  @query(".dialog") private dialogEl!: HTMLElement;

  private cleanup?: () => void;
  private dialogId = `fluid-range-${++counter}`;
  private defaults: { start: string | null; end: string | null } = { start: null, end: null };
  private lastDisplayText = "";

  override connectedCallback(): void {
    super.connectedCallback();
    this.defaults = { start: this.start, end: this.end };
    this.syncFormValue();
    this.listen(document, "pointerdown", this.onDocPointerDown, { capture: true });
  }
  override disconnectedCallback(): void {
    super.disconnectedCallback();
    this.cleanup?.();
  }

  private fmt(iso: string | null): string {
    const d = fromISODate(iso);
    if (!d) return "";
    if (this.datePattern) return this.formatWithPattern(d, this.datePattern);
    const o = fmtOpts(this.format);
    return o ? formatDate(d, this.displayLocale, o) : iso!;
  }

  /** Explicit locale wins; otherwise date display follows the reactive language context. */
  private get displayLocale(): string | undefined {
    const locale = this.locale === undefined ? this.localize.locale : this.locale;
    if (locale === "") return undefined;
    try {
      Intl.getCanonicalLocales(locale);
      return locale;
    } catch {
      return this.locale === undefined ? "en" : undefined;
    }
  }

  private presetLabel(preset: RangePreset): string {
    if (this.presets !== defaultRangePresets) return preset.label;
    const terms = [
      "presetToday",
      "presetYesterday",
      "presetLast7Days",
      "presetLast30Days",
      "presetThisMonth",
      "presetLastMonth"
    ] as const;
    const term = terms[defaultRangePresets.indexOf(preset)];
    return term ? this.term(term) : preset.label;
  }

  private formatWithPattern(date: Date, pattern: string): string {
    const day = date.getDate();
    const month = date.getMonth() + 1;
    const year = date.getFullYear();
    const pad2 = (n: number): string => String(n).padStart(2, "0");
    return pattern.replace(/YYYY|YY|MM|M|DD|D/g, (token) => {
      switch (token) {
        case "YYYY":
          return String(year);
        case "YY":
          return pad2(year % 100);
        case "MM":
          return pad2(month);
        case "M":
          return String(month);
        case "DD":
          return pad2(day);
        default:
          return String(day);
      }
    });
  }

  /**
   * Read text written in {@link datePattern}. Returns null on anything that
   * does not fit, so the caller can fall back or revert — a half-typed date
   * must not silently become some other day.
   */
  private parseWithPattern(text: string, pattern: string): string | null {
    const order: string[] = [];
    let source = "";
    let i = 0;
    while (i < pattern.length) {
      const token = ["YYYY", "YY", "MM", "DD", "M", "D"].find((t) => pattern.startsWith(t, i));
      if (token) {
        order.push(token[0] === "Y" ? "year" : token[0] === "M" ? "month" : "day");
        source += token === "YYYY" ? "(\\d{4})" : token.length === 2 ? "(\\d{2})" : "(\\d{1,2})";
        i += token.length;
      } else {
        source += pattern[i]!.replace(/[^A-Za-z0-9]/g, (c) => "\\" + c);
        i += 1;
      }
    }

    const match = new RegExp("^" + source + "$").exec(text.trim());
    if (!match) return null;

    const parts: Record<string, number> = {};
    order.forEach((name, index) => {
      parts[name] = Number(match[index + 1]);
    });
    if (
      !Number.isFinite(parts["year"]) ||
      !Number.isFinite(parts["month"]) ||
      !Number.isFinite(parts["day"])
    ) {
      return null;
    }

    // Two-digit years land in the current century, matching the pattern's intent.
    const year =
      parts["year"]! < 100
        ? Math.floor(new Date().getFullYear() / 100) * 100 + parts["year"]!
        : parts["year"]!;
    const iso =
      String(year).padStart(4, "0") +
      "-" +
      String(parts["month"]).padStart(2, "0") +
      "-" +
      String(parts["day"]).padStart(2, "0");
    return fromISODate(iso) ? iso : null;
  }

  private get displayText(): string {
    if (this.start && this.end) return `${this.fmt(this.start)} – ${this.fmt(this.end)}`;
    return "";
  }

  protected override willUpdate(changed: PropertyValues<this>): void {
    const displayText = this.displayText;
    if (changed.has("start") || changed.has("end") || this.typed === this.lastDisplayText) {
      this.typed = displayText;
    }
    this.lastDisplayText = displayText;
    if (changed.has("start") || changed.has("end")) {
      this.syncCommittedRange();
    }
    if (changed.has("open") && this.open) this.prepareOpen();
    this.refreshValidity();
  }

  protected override firstUpdated(): void {
    // The first client render supplies the native validation focus anchor.
    this.refreshValidity();
  }

  private syncCommittedRange(): void {
    this.value = this.start && this.end ? `${this.start}/${this.end}` : null;
    this.syncFormValue();
  }

  private refreshValidity(): void {
    const missing = this.required && (!this.start || !this.end);
    this.setValidity(
      missing ? { valueMissing: true } : {},
      missing ? this.term("chooseDateRangeRequired") : undefined,
      this.inputEl ?? undefined
    );
  }

  protected override updated(changed: PropertyValues<this>): void {
    if (changed.has("open")) {
      if (this.open) this.onOpen();
      else this.onClose();
    }
  }

  override formResetCallback(): void {
    this.start = this.defaults.start;
    this.end = this.defaults.end;
    this.typed = this.displayText;
    this.syncCommittedRange();
    this.open = false;
  }
  override formDisabledCallback(d: boolean): void {
    this.disabled = d;
  }
  override formStateRestoreCallback(
    state: string | File | FormData | null,
    _mode: "restore" | "autocomplete"
  ): void {
    void _mode;
    if (typeof state !== "string") return;
    const [start, end, extra] = state.split("/");
    if (extra !== undefined || !fromISODate(start ?? null) || !fromISODate(end ?? null)) return;
    this.start = start!;
    this.end = end!;
    this.typed = this.displayText;
    this.syncCommittedRange();
  }

  private get baseEl(): HTMLElement {
    return this.renderRoot.querySelector(".base") as HTMLElement;
  }

  private onOpen(): void {
    this.dispatchEvent(new CustomEvent("fluid-open", { bubbles: true, composed: true }));
    // Promote to the top layer; :popover-open + @starting-style drive the fade.
    const dialog = this.dialogEl as HTMLElement & { showPopover?: () => void };
    try {
      dialog?.showPopover?.();
    } catch {
      /* already shown or unsupported, ignore */
    }
    this.cleanup = autoUpdate(this.baseEl, this.dialogEl, () => this.reposition());
    void this.reposition();
    // Per the WAI-ARIA APG Date Picker Dialog pattern, move focus into the
    // popover. popover="manual" gives no native focus management and the input
    // is readonly, so without this a keyboard user would have to Tab through the
    // page to reach the grid. Focus the active preset if there is one, otherwise
    // the dialog container itself (tabindex=-1); from there the user Tabs/arrows
    // into the grid. We deliberately do NOT reach into the calendar's nested
    // shadow root (fragile + the focus would escape this dialog's subtree).
    // ...except when the field is typeable. That rationale rests on the input
    // being readonly; a typeable one is a real text field the user may be
    // about to type or paste into, and it Tabs into the dialog on its own.
    // Stealing focus here would send the paste somewhere it cannot be seen.
    if (this.typeable) return;
    requestAnimationFrame(() => {
      const activePreset = this.dialogEl?.querySelector<HTMLButtonElement>(
        ".preset[aria-pressed='true']"
      );
      (activePreset ?? this.dialogEl)?.focus();
    });
  }

  /** Seed draft state before rendering the open dialog. */
  private prepareOpen(): void {
    this.tempStart = this.start;
    this.tempEnd = this.end;
    this.hover = null;
    const anchor = fromISODate(this.start) ?? new Date();
    this.viewISO = toISODate(new Date(anchor.getFullYear(), anchor.getMonth(), 1));
  }
  private onClose(): void {
    this.cleanup?.();
    this.cleanup = undefined;
    const dialog = this.dialogEl as HTMLElement & { hidePopover?: () => void };
    try {
      dialog?.hidePopover?.();
    } catch {
      /* not shown, ignore */
    }
    this.dispatchEvent(new CustomEvent("fluid-close", { bubbles: true, composed: true }));
  }

  private async reposition(): Promise<void> {
    if (!this.baseEl || !this.dialogEl) return;
    const { x, y } = await computePosition(this.baseEl, this.dialogEl, {
      placement: "bottom-start",
      strategy: "fixed",
      middleware: [offset(6), flip(), shift({ padding: 8 })]
    });
    Object.assign(this.dialogEl.style, { left: `${x}px`, top: `${y}px` });
  }

  private onDocPointerDown = (e: Event): void => {
    if (this.open && !e.composedPath().includes(this)) this.open = false;
  };

  private viewDate(): Date {
    return fromISODate(this.viewISO) ?? new Date();
  }
  private goMonth(delta: number): void {
    this.viewISO = toISODate(addMonths(this.viewDate(), delta));
  }

  private onActivate = (e: Event): void => {
    const iso = (e as CustomEvent).detail?.iso as string;
    const picked = fromISODate(iso)!;
    if (!this.tempStart || (this.tempStart && this.tempEnd)) {
      this.tempStart = iso;
      this.tempEnd = null;
    } else {
      const startD = fromISODate(this.tempStart)!;
      if (compareDay(picked, startD) < 0) {
        this.tempEnd = this.tempStart;
        this.tempStart = iso;
      } else {
        this.tempEnd = iso;
      }
    }
    this.hover = null;
  };

  private onHover = (e: Event): void => {
    if (this.tempStart && !this.tempEnd) this.hover = (e as CustomEvent).detail?.iso as string;
  };

  /**
   * Focusing the field opens the calendar, so reaching it by keyboard or by
   * clicking the text offers the same thing a click on the trigger does.
   * Suppressed while returning focus after apply/cancel, which would otherwise
   * reopen the dialog the moment it closed.
   */
  private onInputFocus = (): void => {
    if (this.disabled || this.suppressFocusOpen) return;
    this.open = true;
    if (!this.typeable) return;
    /* Select the whole range so one click is enough to paste over it. Deferred
       a frame because the browser places the caret after this event, which
       would drop a selection made here. */
    requestAnimationFrame(() => {
      if (
        this.inputEl &&
        this.renderRoot instanceof ShadowRoot &&
        this.renderRoot.activeElement === this.inputEl
      ) {
        this.inputEl.select();
      }
    });
  };

  private suppressFocusOpen = false;

  /** Return focus to the field without the focus handler reopening it. */
  private refocusInput(): void {
    this.suppressFocusOpen = true;
    this.inputEl?.focus();
    this.suppressFocusOpen = false;
  }

  private onTyped = (e: Event): void => {
    if (!this.typeable) return;
    this.typed = (e.target as HTMLInputElement).value;
  };

  private onInputKeydown = (e: KeyboardEvent): void => {
    if (e.key === "ArrowDown") {
      e.preventDefault();
      this.open = true;
      return;
    }
    if (!this.typeable) return;
    if (e.key === "Enter") {
      e.preventDefault();
      this.commitTyped();
      this.open = false;
    } else if (e.key === "Escape" && !this.open) {
      e.preventDefault();
      this.typed = this.displayText;
    }
  };

  private onTypedBlur = (e: FocusEvent): void => {
    if (!this.typeable) return;
    /* Clicking a day or a preset blurs the input on the way into the dialog.
       Committing there would fight the click, so only commit once focus has
       actually left the component. */
    const next = e.relatedTarget as Node | null;
    if (next && this.renderRoot instanceof ShadowRoot && this.renderRoot.contains(next)) {
      return;
    }
    this.commitTyped();
  };

  /**
   * Apply what was typed, or put the committed range back.
   *
   * Two dates separated by an en dash, a hyphen, a slash or the word "to".
   * Each side is read as ISO first, then handed to the platform parser, so
   * `2026-08-09 - 2026-08-15` is always understood and the locale-formatted
   * text the field itself displays round-trips. A reversed pair is swapped
   * rather than rejected, and min/max still clamp.
   */
  private commitTyped(): void {
    const text = this.typed.trim();
    if (!text) {
      if (this.start || this.end) {
        this.start = null;
        this.end = null;
        this.emitRangeChange();
      }
      return;
    }

    const parsed = this.parseTypedRange(text);
    if (!parsed) {
      this.typed = this.displayText;
      return;
    }

    let [start, end] = parsed;
    if (start > end) [start, end] = [end, start];
    if (this.min && start < this.min) start = this.min;
    if (this.max && end > this.max) end = this.max;

    if (start === this.start && end === this.end) {
      this.typed = this.displayText;
      return;
    }
    this.start = start;
    this.end = end;
    this.emitRangeChange();
  }

  private parseTypedRange(text: string): [string, string] | null {
    const halves = text.split(/\s*(?:–|—|\bto\b|\/|-(?=\s)|(?<=\s)-)\s*/i);
    const parts = halves.map((part) => part.trim()).filter(Boolean);
    const [from, to] = parts;
    if (parts.length !== 2 || !from || !to) return null;
    const start = this.parseTypedDate(from);
    const end = this.parseTypedDate(to);
    return start && end ? [start, end] : null;
  }

  private parseTypedDate(text: string): string | null {
    if (this.datePattern) {
      return this.parseWithPattern(text, this.datePattern);
    }
    if (/^\d{4}-\d{2}-\d{2}$/.test(text)) {
      return fromISODate(text) ? text : null;
    }
    const parsed = new Date(text);
    return Number.isNaN(parsed.getTime()) ? null : toISODate(parsed);
  }

  private emitRangeChange(): void {
    // Event listeners must observe the same canonical value in FormData.
    this.syncCommittedRange();
    this.dispatchEvent(
      new CustomEvent("fluid-change", {
        detail: {
          start: this.start,
          end: this.end,
          startDate: fromISODate(this.start),
          endDate: fromISODate(this.end)
        },
        bubbles: true,
        composed: true
      })
    );
  }

  private selectPreset(p: RangePreset): void {
    const r = p.getRange();
    this.tempStart = toISODate(r.start);
    this.tempEnd = toISODate(r.end);
    this.viewISO = toISODate(new Date(r.start.getFullYear(), r.start.getMonth(), 1));
  }

  private apply(): void {
    if (!this.tempStart || !this.tempEnd) return;
    this.start = this.tempStart;
    this.end = this.tempEnd;
    this.syncCommittedRange();
    const sd = fromISODate(this.start);
    const ed = fromISODate(this.end);
    this.dispatchEvent(
      new CustomEvent("fluid-change", {
        detail: { start: this.start, end: this.end, startDate: sd, endDate: ed },
        bubbles: true,
        composed: true
      })
    );
    this.open = false;
    this.refocusInput();
  }
  private cancel(): void {
    this.open = false;
    this.refocusInput();
  }

  private onDialogKeydown = (e: KeyboardEvent): void => {
    if (e.key === "Escape") {
      e.preventDefault();
      e.stopPropagation();
      this.cancel();
    }
  };

  override render(): TemplateResult {
    const v = this.viewDate();
    const leftView = toISODate(new Date(v.getFullYear(), v.getMonth(), 1));
    const rightView = toISODate(addMonths(v, 1));
    const activeId =
      this.tempStart && this.tempEnd
        ? matchPreset(
            { start: fromISODate(this.tempStart)!, end: fromISODate(this.tempEnd)! },
            this.presets
          )
        : null;
    const tempLabel =
      this.tempStart && this.tempEnd
        ? `${this.fmt(this.tempStart)} – ${this.fmt(this.tempEnd)}`
        : this.tempStart
          ? `${this.fmt(this.tempStart)} – …`
          : this.term("selectRange");

    return html`
      <div part="base" class="base">
        <input
          part="input"
          type="text"
          .value=${live(this.typed)}
          placeholder=${this.placeholder}
          ?disabled=${this.disabled}
          ?readonly=${this.readonly || !this.typeable}
          role="combobox"
          aria-haspopup="dialog"
          aria-expanded=${this.open ? "true" : "false"}
          aria-controls=${this.dialogId}
          @click=${() => !this.disabled && !this.typeable && (this.open = true)}
          @focus=${this.onInputFocus}
          @input=${this.onTyped}
          @blur=${this.onTypedBlur}
          @keydown=${this.onInputKeydown}
        />
        <button
          part="trigger"
          class="trigger"
          type="button"
          aria-label=${this.term("chooseDateRange")}
          aria-haspopup="dialog"
          aria-expanded=${this.open ? "true" : "false"}
          ?disabled=${this.disabled}
          @click=${() => !this.disabled && (this.open = !this.open)}
        >
          <svg
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            stroke-width="2"
            stroke-linecap="round"
            aria-hidden="true"
          >
            <rect x="3" y="4" width="18" height="18" rx="2"></rect>
            <path d="M16 2v4M8 2v4M3 10h18"></path>
          </svg>
        </button>
      </div>

      <div
        part="dialog"
        id=${this.dialogId}
        class="dialog"
        role="dialog"
        aria-label=${this.term("chooseDateRange")}
        tabindex="-1"
        popover="manual"
        @keydown=${this.onDialogKeydown}
      >
        ${this.noPresets || !this.presets.length
          ? null
          : html` <div
              part="presets"
              class="presets"
              role="group"
              aria-label=${this.term("rangePresets")}
            >
              ${this.presets.map(
                (p) =>
                  html`<button
                    type="button"
                    class="preset"
                    aria-pressed=${activeId === p.id ? "true" : "false"}
                    @click=${() => this.selectPreset(p)}
                  >
                    ${this.presetLabel(p)}
                  </button>`
              )}
            </div>`}
        <div class="right">
          <div class="cal-head">
            <button
              class="nav-button"
              type="button"
              aria-label=${this.term("previousMonth")}
              @click=${() => this.goMonth(-1)}
            >
              ‹
            </button>
            <button
              class="nav-button"
              type="button"
              aria-label=${this.term("nextMonth")}
              @click=${() => this.goMonth(1)}
            >
              ›
            </button>
          </div>
          <div
            part="calendars"
            class="calendars"
            @fluid-date-activate=${this.onActivate}
            @fluid-date-hover=${this.onHover}
          >
            <fluid-calendar
              no-nav
              range
              view=${leftView}
              range-start=${this.tempStart ?? ""}
              range-end=${this.tempEnd ?? ""}
              range-preview=${this.hover ?? ""}
              min=${this.min ?? ""}
              max=${this.max ?? ""}
              week-start=${this.weekStart}
              .locale=${this.locale}
            ></fluid-calendar>
            <fluid-calendar
              no-nav
              range
              view=${rightView}
              range-start=${this.tempStart ?? ""}
              range-end=${this.tempEnd ?? ""}
              range-preview=${this.hover ?? ""}
              min=${this.min ?? ""}
              max=${this.max ?? ""}
              week-start=${this.weekStart}
              .locale=${this.locale}
            ></fluid-calendar>
          </div>
          <div part="footer" class="footer">
            <span class="selected-range">${tempLabel}</span>
            <div class="actions">
              <button class="btn" type="button" @click=${this.cancel}>
                ${this.term("cancel")}
              </button>
              <button
                class="btn apply"
                type="button"
                ?disabled=${!this.tempStart || !this.tempEnd}
                @click=${this.apply}
              >
                ${this.term("apply")}
              </button>
            </div>
          </div>
        </div>
      </div>
    `;
  }
}
